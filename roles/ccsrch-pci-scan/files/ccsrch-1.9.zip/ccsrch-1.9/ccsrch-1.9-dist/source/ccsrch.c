/*
 * ccsrch (c) 2007 Mike Beekey  - zaphod2718@yahoo.com All rights reserved
 * version 1.1: enhanced by T. Arnold, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2010 PSC all rights reserved
 * version 1.1.1: enhanced by M. Dewey, EPX - for those portions marked as 
 *    modified by EPX (c) copyright 2010 EPX all rights reserved
 * version 1.2: enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2010 PSC all rights reserved
 * version 1.3: enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2010 PSC all rights reserved
 * version 1.4: enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2010 PSC all rights reserved
 * version 1.5: enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2010 PSC all rights reserved
 * version 1.6: enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2013 PSC all rights reserved
 * version 1.7 enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2014 PSC all rights reserved
 * version 1.8 enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2015 PSC all rights reserved
 * version 1.9 enhanced by P. Guthrie, PSC - for those portions marked as 
 *    modified by PSC (c) copyright 2016 PSC all rights reserved
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59
 * Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ccsrch.h"
#ifndef WINDOWS
#include <unistd.h>
#endif
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <ctype.h>
#ifdef WINDOWS
#include <windows.h>
#include <Lmcons.h>
#else
#include <pwd.h>
#ifdef LINUX
#include <sys/ptrace.h>
#endif
#endif
#ifndef _AIX
#ifndef __hpux
#include <getopt.h>
#endif
#endif
#include <search.h>

char		*logfilename = NULL;
char		*wlfilename = NULL;
void		*pantree = NULL;
int			panwl = 0;
char		*currfilename = NULL;
FILE		*logfilefd = NULL;
long		total_count = 0;
long		file_count = 0;
unsigned long	block_count = 0;
time_t		currfile_atime=0;
time_t		currfile_mtime=0;
time_t		currfile_ctime=0;
time_t      init_time = 0;
int			cardbuf[CARDSIZE];
int 		print_byte_offset=0;
int 		print_epoch_time=0;
int 		print_julian_time=0;
int 		print_filename_only=0;
int			file_input=0;
char		ccsrch_buf[CCBSIZE];
char		*excludes[MAX_EXCL];
int			max_excludes = 0;
int    		ccsrch_index = 0;
int			tracksrch=0;
int			tracktype1=0;
int			tracktype2=0;
int			trackdatacount=0;
int			windrive = 0;
char		lastfilename[MAXPATH];
int			filename_pan_count=0;
int			whitelist_cnt = 0;
int			excludelist_cnt = 0;
int 		max_hits = 0;
long		max_bytes = 0L;
int			pans_in_file = 0;
int			no_filter = 0;
int			check_mountpoint = 0;
int			postprocess = 0;
int			surrounding_pre = 0;
int			surrounding_post = 0;
char		*resumefile = NULL;
#ifdef WINDOWS
unsigned long long	byte_count = 0L;
#else
unsigned long	byte_count = 0L;
#endif
int			pid_input = 0;
int			inaccessible_cnt = 0;
long		pot_pans = 0L;
long		filter_cnt = 0L;
char		*location;
char		*file_name;
dev_t		cur_dev = (dev_t)0;
int			cur_dev_set = 0;

/* Begin EPX modification */
int     	safe_mode=1;   /* Default to true */
/* End EPX modification */

#ifdef NEEDSSTRSEP
char *strsep(char **str, const char *delims)
{
    char *token;

    if (*str==NULL) {
        /* No more tokens */
        return NULL;
    }

    token=*str;
    while (**str!='\0') {
        if (strchr(delims,**str)!=NULL) {
            **str='\0';
            (*str)++;
            return token;
        }
        (*str)++;
    }
    /* There is no other token */
    *str=NULL;
    return token;
}
#endif

FILE *
outfile()
{
	return logfilefd == NULL ? stdout : logfilefd;
}

void
initialize_buffer()
{
  int	i=0;
  for (i=0; i<CARDSIZE; i++)
    cardbuf[i]=0;
}

int pancmp(const void *a, const void *b)
{
        return strcmp((char *)a,(char *)b);
}

int isinpanlist(int *pan, int len)
{
	void *ret;
	char tmppan[24];
	int i;
	
	/* Convert from ints to chars */

	for (i=0;i < len;i++) {
		tmppan[i] = (char)(pan[i]+'0');
	}
	tmppan[len] = '\0'; 

	ret = tfind(tmppan,&pantree,pancmp);
	if (ret == NULL) return 0;
	return 1;
}

void
read_panlist(FILE *fp)
{
	char panline[MAXPATH + 1];
	void *ret;
	char *cp;

	while (fgets(panline,MAXPATH,fp) != NULL) {
		// skip comments
		if (panline[0] == '#') continue;
		if (strlen(panline) < 2) continue;
		cp = malloc(strlen(panline));
		strncpy(cp,panline,strlen(panline)-1);
		cp[strlen(panline)-1] = '\0';
#ifdef DEBUG
		fprintf(stderr,"Adding %s to whitelist\n",cp);
#endif

		ret = tsearch(cp,&pantree,pancmp);
	}
}

void buildPanList(char *filename)
{
	FILE *filep = NULL;
#ifdef DEBUG
	fprintf(stderr,"Reading Whitelist file %s\n",filename);
#endif
	if (filename != NULL) {
		filep = fopen(filename, "r");
		if (filep == NULL) {
			fprintf(stderr, "Unable to open PAN list file (%s) for read; errorno=%d\n", filename, errno);
			return;
		}
		read_panlist(filep);
	}
	return;
}

void
buildExcludeList(char *arg1)
{
	char *aPtr;
    int count = 0;
	
        if (!arg1) return;
	
    do {
        aPtr = strsep(&arg1, ",");
        if (aPtr && count < MAX_EXCL) excludes[count++] = aPtr;
    } while(aPtr && count < MAX_EXCL);
	
	max_excludes = count;
	
	return;
}



struct excludelist {
	char *path;
	struct excludelist *next;
};

struct excludelist *excludelist = NULL;

void
read_excludelist(FILE *fp)
{
	char elline[MAXPATH + 1];
	int i,goodp;
	struct excludelist *lastel = NULL;

	while (fgets(elline,MAXPATH,fp) != NULL) {
		// skip comments
		if (elline[0] == '#') continue;
		if (strlen(elline) < 2) continue;

		if (lastel == NULL) {
			excludelist = malloc(sizeof(struct excludelist));
			lastel = excludelist;
		} else {
			lastel->next = malloc(sizeof(struct excludelist));
			lastel = lastel->next;
		}
		lastel->next = NULL;
		lastel->path = malloc(strlen(elline));
		strncpy(lastel->path,elline,strlen(elline)-1);
		lastel->path[strlen(elline)-1] = '\0';
	}
}

void
loadExcludeFile(char *arg1)
{
	FILE *elfile = NULL;
	if (arg1 != NULL) {
		elfile = fopen(arg1, "r");
		if (elfile == NULL) {
			fprintf(stderr, "Unable to open exclude list file (%s) for read; errno=%d\n", arg1, errno);
			return;
		}
		read_excludelist(elfile);
	}
	return;
}

#ifdef WINDOWS
int
pathcmp(char *p1, char *p2, int pathlen)
{
        char c1,c2;
        while (--pathlen >= 0) {
                c1 = *p1; c2 = *p2;
                if (c1 == '\\') c1 = '/';
                if (c2 == '\\') c2 = '/';
                if (toupper(c1) != toupper(c2)) return -1;
                p1++; p2++;
                if ((pathlen > 0) && ((*p1 == '\0') || (*p2 == '\0'))) return -1; /* A string terminates early */
        }
        return 0;

}
#endif

int
excludelist_lookup(char *path)
{
	int i,found;
	struct excludelist *listptr = excludelist;
#ifdef WINDOWS
	TCHAR realpath[MAXPATH];
	TCHAR realtest[MAXPATH];
#else
	char *rp;
#endif
	
	if (path == NULL) return 0;

#ifndef WINDOWS
	if ((rp=realpath(path,NULL)) == NULL) return 0;
#else
	if (GetFullPathName(path,MAXPATH,realpath,NULL) == 0) {
		fprintf(stderr,"Unable to retrieve full path of %s\n");
		return 0;
	};

#endif

#ifdef LINUX
	if (strcmp("/proc/kcore",rp) == 0) return 1;
#endif
	
	while (listptr != NULL) {
#ifdef DEBUG
		printf("Testing exclude [%s] against list [%s]\n",path,listptr->path);
#endif
#ifdef WINDOWS
		if (GetFullPathName(listptr->path,MAXPATH,realtest,NULL) == 0) {
			fprintf(stderr,"Unable to retrieve full path of %s\n");
			return 0;
		};
#ifdef DEBUG
		printf("Checking [%s] against [%s]\n",realpath,realtest);
#endif

		if (pathcmp(realpath,realtest,strlen(realtest)) == 0) {
#else
		if (strncmp(listptr->path,path,strlen(listptr->path)) == 0) {
#endif
			excludelist_cnt++;
#ifndef WINDOWS
			free(rp);
#endif
			return 1;
		}
#ifndef WINDOWS
		/* Do absolute paths - we've already done this for Windows */
		if (listptr->path[0] == '/') {
			/* Get absolute path name */
#ifdef DEBUG
			printf("Testing exclude [%s] against list [%s]\n",rp,listptr->path);
#endif
			if (strncmp(listptr->path,rp,strlen(listptr->path)) == 0) {
				excludelist_cnt++;
				free(rp);
				return 1;
			}
		}
#endif
		listptr = listptr->next;
	}
#ifndef WINDOWS
	free(rp);
#endif
	return 0; /* Not in excludelist */
}


struct {
	char shortname;
	char *longname;
} cardtypes[] = {
	{'M',"MasterCard"},
	{'V',"Visa"},
	{'A',"Amex"},
	{'D',"Discover"},
	{'m',"Maestro"},
	{'s',"Solo"},
	{'S',"Switch"},
	{'J',"JCB"},
	{'E',"Enroute"},
	{'d',"Diners-Club-Carte-Blanche"}
};
#define CARDTYPEMAX 10

void 
print_result(char cardtype, int cardlen, unsigned long byte_offset)
{
  int	i = 0, l4offset, curtrack = 0, chars = 0;
  char	nbuf[20];
  char	buf[MAXPATH];
  char	basebuf[MDBUFSIZE];
  char	bytebuf[MDBUFSIZE];
  char	datebuf[MDBUFSIZE];
  char	mdatebuf[CARDTYPELEN];
  char	adatebuf[CARDTYPELEN];
  char	cdatebuf[CARDTYPELEN];
  char	trackbuf[MDBUFSIZE];
  char	*cardname = "Unknown card type";
  char	*prebuf, *postbuf, *cp, *contextpan;

  memset(&nbuf, '\0', 20);

	total_count++;
	pans_in_file++;
	
	if (postprocess && (pans_in_file == 1)) {
		fprintf(outfile(),"F|%s\n",file_name);
	}
	
	for (i=0;i<CARDTYPEMAX;i++) {
		if (cardtypes[i].shortname == cardtype)
			cardname = cardtypes[i].longname;
	}

/* Begin EPX modifications */
  l4offset = cardlen - 4;
  for (i=0; i < cardlen; i++)
  {
    if (safe_mode)
	{
      if ((i < 6) || (i >= l4offset))
	    nbuf[i] = cardbuf[i]+48;
      else
        nbuf[i] = '*';
    }
    else
      nbuf[i] = cardbuf[i]+48;	
  }
/* End EPX modifications   */

  memset(&buf,'\0',MAXPATH);
  memset(&basebuf,'\0',MDBUFSIZE);

  if (print_filename_only)
    snprintf(basebuf, MDBUFSIZE, "%s", currfilename);
  else
    snprintf(basebuf, MDBUFSIZE, "%s\t%s\t%s", currfilename, cardname, nbuf);

  strncat(buf,basebuf,MAXPATH);

    if (print_byte_offset)
    {
      memset(&bytebuf,'\0',MDBUFSIZE);
      snprintf(bytebuf, MDBUFSIZE, "\t%lu", byte_offset);
      strncat(buf,bytebuf,MAXPATH);
    }

    if (print_julian_time)
    {
      memset(&mdatebuf,'\0',CARDTYPELEN);
      strncpy(mdatebuf,ctime((time_t *)&currfile_mtime),CARDTYPELEN);
      mdatebuf[strlen(mdatebuf)-1]='\0';

    memset(&adatebuf,'\0',CARDTYPELEN);
    strncpy(adatebuf,ctime((time_t *)&currfile_atime),CARDTYPELEN);
    adatebuf[strlen(adatebuf)-1]='\0';

    memset(&cdatebuf,'\0',CARDTYPELEN);
    strncpy(cdatebuf,ctime((time_t *)&currfile_ctime),CARDTYPELEN);
    cdatebuf[strlen(cdatebuf)-1]='\0';

      memset(&datebuf,'\0',MDBUFSIZE);
      snprintf(datebuf, MDBUFSIZE, "\t%s\t%s\t%s", mdatebuf,adatebuf,cdatebuf);
      strncat(buf,datebuf,MAXPATH);
    }

    if (print_epoch_time)
    {
      memset(&datebuf,'\0',MDBUFSIZE);
      snprintf(datebuf, MDBUFSIZE, "\t%ld\t%ld\t%ld", currfile_mtime,currfile_atime,currfile_ctime);
      strncat(buf,datebuf,MAXPATH);
    }

    if (tracksrch)
    {
      memset(&trackbuf,'\0',MDBUFSIZE);
      if (tracktype1)
      {
        if (track1_srch(cardlen))
        {
		  curtrack = 1;
          snprintf(trackbuf, MDBUFSIZE, "\tTRACK_1");
        }
      }
      if (tracktype2)
      {
        if (track2_srch(cardlen))
        {
		  curtrack = 2;
          snprintf(trackbuf, MDBUFSIZE, "\tTRACK_2");
        }
      }
      strncat(buf,trackbuf,MAXPATH);
    }

	if ((surrounding_pre + surrounding_post) > 0) {
		contextpan = (char *)malloc(surrounding_pre + surrounding_post + cardlen + 1);
		*contextpan = '\0';
	
		if (surrounding_pre > 0) {
			prebuf = (char *)malloc(surrounding_pre + 1);
			cp = &ccsrch_buf[ccsrch_index-cardlen+1]; /* start of PAN */
			i = surrounding_pre;
			chars = 0;
			while ((cp-- > ccsrch_buf) && (i-- > 0) && (*cp != '\n') && (*cp != '\r')) {
				chars++;
			}
			cp++; 
		
			i=0;
			/* Now cp is at our start */
			while (chars-- > 0) {
				prebuf[i] = (isprint(cp[i]) || (cp[i] == '|') || (cp[i] == ' ')) ? cp[i] : '?';
				i++;
			}
			prebuf[i] = '\0';
			strncpy(contextpan,prebuf,strlen(prebuf));
			contextpan[strlen(prebuf)] = '\0';
			free(prebuf);
		}		
		strncat(contextpan,nbuf,strlen(nbuf));
	
		if (surrounding_post > 0) {
			postbuf = (char *)malloc(surrounding_post + 2);
			cp = &ccsrch_buf[ccsrch_index+1];
			i = 0;
			chars = 0;
			while ((i<surrounding_post) && (cp < &ccsrch_buf[CCBSIZE]) && (*cp!='\n') && (*cp != '\r')) {
				postbuf[i] = (isprint(*cp) || *cp == '|' || *cp == ' ') ? *cp : '?';
				i++; cp++;
			}
			postbuf[i] = '\0';
			strncat(contextpan,postbuf,strlen(postbuf));
			free(postbuf);
		}
	} else {
		contextpan = (char *)malloc(1);
		*contextpan = '\0';
	}
	

    if (!postprocess) {
		if (*contextpan != '\0') {
			fprintf(outfile(), "%s [%s]\n", buf,contextpan);
		} else {
			fprintf(outfile(), "%s\n", buf);
		}
	} else {
		fprintf(outfile(), "H|%s|%c|%d|%lu|%s\n",nbuf,cardtype,curtrack,byte_offset,contextpan);
	}


}

int track1_srch(int cardlen)
{
  /* [%:B:cardnum:^:name (first initial cap?)] */
  if ((ccsrch_buf[ccsrch_index+1] == '^')	/* Separator */
    && (ccsrch_buf[ccsrch_index-cardlen] == 'B')	/* Format */
    && (ccsrch_buf[ccsrch_index-(cardlen+1)] == '%')	/* Start sentinel */
    && (ccsrch_buf[ccsrch_index+2] > 'A')
    && (ccsrch_buf[ccsrch_index+2] < 'Z'))
  {
    trackdatacount++;
    return(1);
  }
  else
    return(0);
}

int track2_srch(int cardlen)
{
  /* [;:cardnum:=:expir date(YYMM), we'll use the ; here] */
  if (((ccsrch_buf[ccsrch_index+1] == '=') || (ccsrch_buf[ccsrch_index+1] == 68))
    && ((ccsrch_buf[ccsrch_index-cardlen] == ';') 
 /*   || ((ccsrch_buf[ccsrch_index-cardlen] > 57) || (ccsrch_buf[ccsrch_index-cardlen] < 91)) */ ) /* Pretty much always see start sentinels of ; */
    && ((ccsrch_buf[ccsrch_index+2] >= '0')
    && (ccsrch_buf[ccsrch_index+2] <= '9'))
    && ((ccsrch_buf[ccsrch_index+3] >= '0')
    && (ccsrch_buf[ccsrch_index+3] <= '9')))
  {
    trackdatacount++;
    return(1);
  }
  else
    return(0);
}


int 
process_prefix(int len, unsigned long offset)
{
  switch (len)
  {
/* Begin EPX additions */  
  case 19:
	check_maestro_12_19(offset, len);
	check_solo_16_18_19(offset, len);
	check_switch_16_18_19(offset, len);
    break;
  case 18:
	check_maestro_12_19(offset, len);
	check_solo_16_18_19(offset, len);
	check_switch_16_18_19(offset, len);
    break;
  case 17:
	check_maestro_12_19(offset, len);
    break;
/* End EPX additions */  
  case 16:
    check_mastercard_16(offset);
    check_visa_16(offset);
    check_discover_16(offset);
    check_jcb_16(offset);
/* Begin EPX additions */  
	check_maestro_12_19(offset, len);
	check_solo_16_18_19(offset, len);
	check_switch_16_18_19(offset, len);
/* End EPX additions */  
    break;
  case 15:
    check_amex_15(offset);
    check_enroute_15(offset);
    check_jcb_15(offset);
/* Begin EPX additions */  
	check_maestro_12_19(offset, len);
/* End EPX additions */  
    break;
  case 14:
    check_diners_club_cb_14(offset);
/* Begin EPX additions */  
	check_maestro_12_19(offset, len);
    break;
  case 13:
	check_maestro_12_19(offset, len);
    break;
  case 12:
	check_maestro_12_19(offset, len);
    break;
/* End EPX additions */  
  }
  return (0);
}


struct whitelist {
	char *pan;
	struct whitelist *next;
};

struct whitelist *whitelist = NULL;

void
read_whitelist(FILE *fp)
{
	char wlline[129];
	int i,goodp;
	struct whitelist *lastwl = NULL;

	while (fgets(wlline,128,fp) != NULL) {
		// skip comments
		if (wlline[0] == '#') continue;
		if (strlen(wlline) < 2) continue;
		goodp = 1;
		for (i=0;i<strlen(wlline)-1;i++) {
			if (!isdigit(wlline[i])) {
				goodp = 0;
				break;
			}
		}
		if (!goodp) continue;
		// OK Good PAN, BIN, or whatever.
		if (lastwl == NULL) {
			whitelist = malloc(sizeof(struct whitelist));
			lastwl = whitelist;
		} else {
			lastwl->next = malloc(sizeof(struct whitelist));
			lastwl = lastwl->next;
		}
		lastwl->next = NULL;
		lastwl->pan = malloc(strlen(wlline));
		strncpy(lastwl->pan,wlline,strlen(wlline)-1);
		lastwl->pan[strlen(wlline)] = '\0';
	}
}

int
open_whitelist()
{
	FILE *wlfilefd = NULL;
	if (wlfilename != 0) {
		wlfilefd = fopen(wlfilename, "r");
		if (wlfilefd == NULL) {
			fprintf(stderr, "Unable to open whitelist file (%s) for read; errorno=%d\n", wlfilename, errno);
			return (-1);
		}
		read_whitelist(wlfilefd);
	}
	return 0;
}

int
whitelist_lookup(int *cb, int len)
{
	int i,found;
	struct whitelist *listptr = whitelist;

	while (listptr != NULL) {
		i = 0;
		found = 1;
		for (i=0;i < ((strlen(listptr->pan) > len) ? len : strlen(listptr->pan));i++) {
			if (listptr->pan[i] != (char)(cb[i]+'0')) {
				found = 0;
				break;
			}
		}
		if (found) {
			whitelist_cnt++;
			return 1;
		}
		listptr = listptr->next;
	}
	return 0; /* Not in whitelist */
}

/*
 * Programmatic filters for likely suspect PANs - ones that probably are not... repeating patterns, etc.
 */

int
should_filter(int *cardbuf, int len)
{
	short digcnt[10];
	short diffdigs = 0;
	short i=0;
	
	if (no_filter)
		return 0;
		
	for (i=0;i<10;i++) {
		digcnt[i] = 0;
	}
		
	for (i=0;i<len;i++) {
		digcnt[cardbuf[i]]++;
	}
	
	/* Current rules:
	 * 1: Different digits < threshold, filter (e.g. 5454545454545454)
	 * 2: Same digits > threshold, filter (e.g. 4111111111111111)
	 */
	
	for (i=0;i<10;i++) {
		if (digcnt[i] != 0) diffdigs++;
		if (digcnt[i] > MAX_DIGS_FILTER) {
			filter_cnt++;
			return 1;
		}
	}
	if (diffdigs < MIN_DIFF_FILTER) {
		filter_cnt++;
		return 1;
	}
	
	return 0;
}

int 
luhn_check(int len, unsigned long offset)
{
  int    i = 0;
  int    tmp = 0;
  int    total = 0;
  int    nummod = 0;
  int            num[CARDSIZE];


  if (cardbuf[i]<=0)
    return(0);

#ifdef DEBUG
char d1[24];
for (i=0; i<len; i++)
 d1[i]=cardbuf[i]+'0';
d1[len] = '\0';
fprintf(stderr,"Checking %s\n",d1);
#endif

  for (i=0; i<CARDSIZE; i++)
    num[i]=0;

  for (i=0; i<len; i++)
   num[i]=cardbuf[i];

  for (i=len-2; i>=0; i-=2)
  {
    tmp=2*num[i];
    num[i]=tmp;
    if (num[i]>9)
      num[i]-=9;
  }

  for (i = 0; i < len; i++)
    total += num[i];


  nummod = total % 10;
  if (nummod == 0)
  {
		pot_pans++;
		/* Check if not in whitelist of PANs to exclude and check if in whitelist of PANs to only process and should not filter the PAN */
		if (!whitelist_lookup(cardbuf,len) && (!panwl || isinpanlist(cardbuf,len)) && !should_filter(cardbuf,len)) {
						/* Otherwise check in BIN tables */
						process_prefix(len, offset);
		}
  }
  return (nummod);
}


int 
ccsrch(char *filename, int specialflag)
{
	FILE           *in = NULL;
	int             infd = 0;
	int             cnt = 0;
	unsigned long		  byte_offset=1;
	int    k = 0;
	int    counter = 0;
	int    total = 0;
	int    check = 0;
	long	curbytes = 0L;
	int rpid = 0;
	FILE *mapfp = NULL;
	char memfilename[256];
#ifdef WINDOWS
	HANDLE hFile;
	HANDLE hProc;
	MEMORY_BASIC_INFORMATION mbi;
	unsigned char *p, *segstart;
	TOKEN_PRIVILEGES tp;
	LUID luid;
	SIZE_T bytes_read;
	DWORD readsz;
#endif
#if defined(LINUX) || defined(WINDOWS)
	struct addrsll {
#ifdef WINDOWS
		long long addr1;
#else
		long addr1;
#endif
		long rsize;
		struct addrsll *n;
	} *addrstart,*addrcurr;
#endif
#ifdef LINUX
	char mapline[256];
	char * dash;
	int writeflag = 0;
#endif
	
	memset(&lastfilename,'\0',MAXPATH);
	ccsrch_index=0;
	pans_in_file = 0;
	pot_pans = filter_cnt = 0L;
	errno = 0;

	if (specialflag == IS_PID) {
		rpid = atoi(filename);
		if (rpid <= 0) {
			fprintf(stderr,"Unable to read PID number %s\n",filename);
		}

#ifdef LINUX
		/* Now do Linux Specific Read of Memory */
		sprintf(memfilename,"/proc/%d/mem",rpid);
		infd = open(memfilename,0);
		if (infd < 0) {
			fprintf(stderr,"Unable to open memory file for read %s\n",memfilename);
			return (-1);
		}
		currfilename = malloc(strlen(memfilename)+1);
		strcpy(currfilename,memfilename);
		
		ptrace(PTRACE_ATTACH,rpid,NULL,NULL);
		
		sprintf(memfilename,"/proc/%d/maps",rpid);
		if ((mapfp=fopen(memfilename,"r")) == NULL) {
			fprintf(stderr,"Unable to read memory maps for PID %d\n",rpid);
			exit(1);
		}
		
		addrstart = addrcurr = malloc(sizeof(struct addrsll));
		while (fgets(mapline,256,mapfp)) {
			writeflag = 0;
			dash = strchr(mapline,'-');
			if (dash == NULL) continue;
			*dash = '\0';
			dash++;
			dash = strchr(dash,' ');
			dash++;
			addrcurr->addr1 = strtol(mapline,NULL,16);
			/* Now see if it's a readwrite segment... */
			while (*(++dash)!=' ') {
				if (*dash == 'w')
					writeflag = 1;
			}
			
			if (!writeflag) continue;
					
#ifdef DEBUG
			fprintf(stderr,"Making segment at %lX\n",addrcurr->addr1);
#endif
			addrcurr->n = malloc(sizeof(struct addrsll));
			addrcurr = addrcurr->n;
			
		}
		
		addrcurr->n = (struct addrsll *)0;
		addrcurr = addrstart;
		
		lseek(infd,addrcurr->addr1,0);
				
#endif
		
#ifdef WINDOWS
		/* Enable Debugging in Self */
		currfilename = malloc(30);
		sprintf(currfilename,"PID%d",rpid);
		if (!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES,&hProc)) {
			fprintf(stderr,"Unable to open current process!  Perhaps you need to be an admin?\n");
			exit(1);
		}
		LookupPrivilegeValue(NULL,SE_DEBUG_NAME,&luid);
		tp.PrivilegeCount = 1;
		tp.Privileges[0].Luid = luid;
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		if (!AdjustTokenPrivileges(hProc,FALSE,&tp,sizeof(TOKEN_PRIVILEGES),(PTOKEN_PRIVILEGES)NULL,(PDWORD)NULL)) {
			fprintf(stderr,"Unable to set DEBUG on my process!  Perhaps you need to be an admin?\n");
			exit(1);			
		}
		/* Now Windows Specific Memory Read - Get Segments*/
		hProc = OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_INFORMATION, 0, rpid);
		if (hProc == NULL) {
			fprintf(stderr, "Unable to open process %d for read.  Perhaps you need to be an admin or you got the PID wrong?\n", rpid);
			exit(1);
		}
		addrstart = addrcurr = malloc(sizeof(struct addrsll));
		for (p = NULL; VirtualQueryEx(hProc, p , &mbi, sizeof(mbi)) == sizeof(mbi) ; p += mbi.RegionSize ) {
			if (mbi.State == MEM_COMMIT && (mbi.Type == MEM_MAPPED || mbi.Type == MEM_PRIVATE)
				&& ((mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ)) == 0) ) {
				addrcurr->addr1 = (long long)p;
				addrcurr->rsize = mbi.RegionSize;
#ifdef DEBUG
				fprintf(stderr,"Making segment at %lX of %lx length\n",addrcurr->addr1,addrcurr->rsize);
#endif
				addrcurr->n = malloc(sizeof(struct addrsll));
				addrcurr = addrcurr->n;
			}
		}
		addrcurr->n = (struct addrsll *)0;
		addrcurr = addrstart;
		segstart = p = (unsigned char *)addrstart->addr1;

#ifdef DEBUG
		fprintf(stderr,"Finished making segments\n");
#endif
		
#endif
	} else
	if (specialflag == IS_SPECIAL) {
		/*
		 * Can be:
		 *    - : stdin
		 *  0-9 : a physical drive in Windows
		 *  A-Z : a logical drive in Windows
		 */
		if (filename[0] == '-') {
			in = fdopen(0,"rb");
			if (in == NULL) {
				fprintf(stderr, "ccsrch: Unable to open file %s for reading; errno=%d\n", filename, errno);
				inaccessible_cnt++;
				return (-1);
			}
			infd = 0;
			currfilename = "<stdin>";
		}
#ifdef WINDOWS
		else if (windrive) {
	
			char fname[100];
			LPCSTR w = fname;
			if (strlen(filename) > 1) {
				usage("ccsrch");
				exit(1);
			}
			if ((*filename >= '0') && (*filename <= '9')) {		
				sprintf(fname,"\\\\.\\PHYSICALDRIVE%c",*filename);
				currfilename = strdup("Physical Drive X");
				currfilename[strlen(currfilename)-1] = *filename;			
			} else {
				if (((*filename >= 'A') && (*filename <= 'Z')) || ((*filename >= 'a') && (*filename <= 'z'))) {				
					sprintf(fname,"\\\\.\\%c:",*filename);
					currfilename = strdup("Logical Volume X");
					currfilename[strlen(currfilename)-1] = *filename;					
				} else {
					fprintf(stderr,"Invalid Windows physical or logical drive name... must be 0..9 or A..Z\n");
					exit(1);
				}
			}
		
			hFile = CreateFile(w,     // file to create
							   GENERIC_READ | GENERIC_WRITE,                                     // open for writing
							   FILE_SHARE_READ | FILE_SHARE_WRITE, 
							   NULL,                                                           // default security
							   OPEN_EXISTING,                                  // overwrite existing
							   FILE_ATTRIBUTE_NORMAL,                  // asynchronous I/O
							   NULL);                                                         // no attribute template
			
			if(hFile == INVALID_HANDLE_VALUE)
				fprintf(stderr,"Could not open %s file, error %u.\n", fname, GetLastError());
			
			fprintf(stderr,"Opened %s for reading\n",currfilename);		
		}			
#endif
		else {
			fprintf(stderr,"Invalid special file [%s]\n",filename);
			exit(1);
		}
		
	} else { /* Regular file */
		if (resumefile != NULL) { /* if we are using a restore point, skip files until we reach the store point */
			if (strcmp(filename,resumefile) == 0)
				resumefile = NULL;
			else
				return -1;
		}
		if (max_excludes > 0) {
			int i;
			char *w1,*filestart=filename;
			for (w1=filename;*w1 != '\0';w1++)
				if (*w1 == '/')
					filestart = w1;
			
			for (--w1;w1>filestart;--w1) /* walk backwards to get the '.' */
				if (*w1 == '.')
					break;
			
			if (w1 != filestart) /* a '.' in name */
				for (++w1,i=0;i < max_excludes;i++)
					if (strcasecmp(excludes[i],w1) == 0)
						return -1;
		}
		if (excludelist_lookup(filename)) {
			return -1;
		}
		in = fopen(filename, "rb");
		if (in == NULL)
		{
			inaccessible_cnt++;
			if (errno==13)
				fprintf(stderr, "ccsrch: Unable to open file %s for reading; Permission Denied\n", filename);
			else
				fprintf(stderr, "ccsrch: Unable to open file %s for reading; errno=%d\n", filename, errno);
			return (-1);
		}
		infd = fileno(in);
		currfilename = filename;
	}
	byte_offset=1;
	
	file_name = filename; /* make global. Yuck */
	file_count++;
	
	initialize_buffer();
	
	while (1)
	{
		memset(&ccsrch_buf, '\0', CCBSIZE);
#ifdef WINDOWS
		if (windrive) {
			
			if (ReadFile(hFile, &ccsrch_buf, CCBSIZE, &readsz, NULL) == FALSE) {
				fprintf(stderr,"Could not read, error %u.\n", GetLastError());
				break;
			} else {
				cnt = readsz;
			}
		} else
		if (specialflag == IS_PID) {
			if (!ReadProcessMemory(hProc,p,&ccsrch_buf,(SIZE_T)(addrcurr->rsize < CCBSIZE ? addrcurr->rsize : CCBSIZE),&bytes_read)) {
				fprintf(stderr,"Skipping memory segment at %lx\n",p);
				if (addrcurr->n != NULL) {
					addrcurr = addrcurr->n;
#ifdef DEBUG
					fprintf(stderr,"Seeking new segment at %lX\n",addrcurr->addr1);
#endif
					segstart = p = (unsigned char *)addrcurr->addr1;
					continue;
				} else {
					break;
				}
			} else {
				cnt = bytes_read;
			}
#ifdef DEBUG
			fprintf(stderr,"Read %d bytes of memory at %lX\n",cnt,p);
#endif
		} else {
#endif
		cnt = read(infd, &ccsrch_buf, CCBSIZE);	/* This is the main read function for everything */
#ifdef WINDOWS
		}
#endif
		
		block_count++;
		if (specialflag == IS_PID) {
#ifdef LINUX
			if (cnt < CCBSIZE) {
			/* Find the next segment */
				if (addrcurr->n != NULL) {
					addrcurr = addrcurr->n;
#ifdef DEBUG
 					fprintf(stderr,"Seeking new segment at %lX\n",addrcurr->addr1);
#endif
					lseek(infd,addrcurr->addr1,0);
					continue;
				} else {
					break;
				}
			}
#endif

		} else {
			if (cnt <= 0)
				break;
		}
		ccsrch_index = 0;
		byte_count += cnt;
		
		curbytes += cnt;
		
		if ((max_bytes > 0L) && (curbytes > max_bytes))
			break;
		
		while (ccsrch_index < cnt)
		{
			if ((ccsrch_buf[ccsrch_index] > 47) && (ccsrch_buf[ccsrch_index] < 58))
			{
				check = 1;
				cardbuf[counter] = ((int)ccsrch_buf[ccsrch_index])-48;
				counter++;
			} else if ((ccsrch_buf[ccsrch_index] != 0) && (ccsrch_buf[ccsrch_index] != 10) && (ccsrch_buf[ccsrch_index] != 13))
			{
				/*
				 * we consider nulls, new lines, and carriage
				 * returns to be noise, so ingore those,
				 * otherwise, restart the count
				 */
				check = 1;
				counter = 0;
			} else {
				check = 0;
				initialize_buffer();
				counter=0;
			}
			
			if (((counter > 12) && (counter < CARDSIZE)) && (check)) 
			{
				switch (counter)
				{
						/* EPX addition - support for 17-19 digit Maestro, Solo and Switch cards */
					case 19:
						luhn_check(19,byte_offset-19);
						break;
					case 18:
						luhn_check(18,byte_offset-18);
						break;
					case 17:
						luhn_check(17,byte_offset-17);
						break;
						/* End EPX addition */		  
					case 16:
						luhn_check(16,byte_offset-16);
						break;
					case 15:
						luhn_check(15,byte_offset-15);
						break;
					case 14:
						luhn_check(14,byte_offset-14);
						break;
					case 13:
						luhn_check(13,byte_offset-13);
						
						/* EPX addition - support for 12 digit Maestro card */		  
					case 12:
						luhn_check(12,byte_offset-12);
						/* End EPX addition */		  
						break;
				}
			} else if ((counter == CARDSIZE) && (check)) 
			{
				for (k = 0; k < counter - 1; k++)
				{
					cardbuf[k] = cardbuf[k + 1];
				}
				cardbuf[k] = (-1);
				luhn_check(12,byte_offset-12);	/* EPX addition - support for 12 digit Maestro card */		  
				luhn_check(13,byte_offset-13);
				luhn_check(14,byte_offset-14);
				luhn_check(15,byte_offset-15);
				luhn_check(16,byte_offset-16);
				/* EPX addition - support for 17-19 digit Maestro, Solo and Switch cards */
				luhn_check(17,byte_offset-17);
				luhn_check(18,byte_offset-18);
				luhn_check(19,byte_offset-19);
				/* End EPX addition */		  
				counter--;
			}
			/* If we've hit our limit... next file please */
			if (max_hits > 0 && pans_in_file >= max_hits)
				break;
			byte_offset++;
			ccsrch_index++;
		}
#ifdef WINDOWS
		if (specialflag == IS_PID) {
			if ((cnt < CCBSIZE) || (((p+cnt) - segstart) >= addrcurr->rsize)) {
				if (addrcurr->n != NULL) {
					addrcurr = addrcurr->n;
#ifdef DEBUG
 					fprintf(stderr,"Seeking new segment at %lX\n",addrcurr->addr1);
#endif
					segstart = p = (unsigned char *)addrcurr->addr1;
					continue;
				} else {
					break;
				}
			} else {
				p += CCBSIZE; /* Increment memory to read */
			}
		}
#endif
		/* Added to fix pseudo devices like /proc stuff which returns < blocksize results over and over again */
		if (cnt < CCBSIZE)
			break;
		/* One more level out if we've hit our limit */
		if (max_hits > 0 && pans_in_file >= max_hits)
			break;
	}
	if (specialflag == IS_PID) {
#ifdef LINUX
		ptrace(PTRACE_DETACH, rpid, NULL, NULL);
#endif		
	} else
	if (!windrive)
		fclose(in);
#ifdef WINDOWS
	else
		CloseHandle(hFile);
#endif

	if (postprocess && (pans_in_file > 0)) {
		fprintf(outfile(),"FE|%s|%ld|%ld\n",filename,pot_pans,filter_cnt); /* Fix with stats */
	}
	
	return (total);
}


int 
escape_space(char *infile, char *outfile)
{
  int    i = 0;
  int    spc = 0;
  char           *tmpbuf = NULL;
  int    filelen = 0;
  int    newlen = 0;
  int    newpos = 0;

  filelen = strlen(infile);
  for (i = 0; i < filelen; i++)
    if (infile[i] == ' ')
      spc++;

  newlen = filelen + spc + 1;
  errno = 0;
  tmpbuf = (char *)malloc(newlen);
  if (tmpbuf == NULL)
  {
    fprintf(stderr, "escape_space: can't allocate memory; errno=%d\n", errno);
    return (1);
  }
  memset(tmpbuf, '\0', newlen);

  i = 0;
  while (i < filelen)
  {
    if (infile[i] == ' ')
    {
      tmpbuf[newpos++] = '\\';
      tmpbuf[newpos] = infile[i];
    } else
      tmpbuf[newpos] = infile[i];
    newpos++;
    i++;
  }
  strncpy(outfile, tmpbuf, newlen);
  free(tmpbuf);
  return (0);
}

int 
get_file_stat(char *inputfile, struct stat * fileattr)
{
  struct stat     ffattr;
  int             err = 0;
  char           *tmp2buf = NULL;
  int    filelen = 0;


  filelen = strlen(inputfile);
  errno = 0;
  tmp2buf = (char *) malloc(filelen+1);
  if (tmp2buf == NULL)
  {
    fprintf(stderr, "get_file_stat: can't allocate memory; errno=%d\n", errno);
    return (1);
  }
  memset(tmp2buf, '\0', filelen+1);
  strncpy(tmp2buf, inputfile, filelen);

  errno=0;
#ifdef WINDOWS
  err = stat(tmp2buf, &ffattr);
#else
  err = lstat(tmp2buf, &ffattr);
#endif
  if (err != 0)
  {
    if (errno == ENOENT)
      fprintf(stderr, "get_file_stat: File %s not found, can't get stat info\n", inputfile);
    else
      fprintf(stderr, "get_file_stat: Cannot stat file %s; errno=%d\n", inputfile, errno);
    free(tmp2buf);
    return (-1);
  }
  memcpy(fileattr, &ffattr, sizeof(ffattr));
  currfile_atime=ffattr.st_atime;
  currfile_mtime=ffattr.st_mtime;
  currfile_ctime=ffattr.st_ctime;
  free(tmp2buf);
  return (0);
}

int 
proc_dir_list(char *instr)
{
  DIR            *dirptr;
  struct dirent  *direntptr;
  int             dir_name_len = 0;
  char           *curr_path = NULL;
  struct stat     fstat;
  int             err = 0;
  char            tmpbuf[4096];

  errno = 0;
  dir_name_len = strlen(instr);
  dirptr = opendir(instr);

  /* Check to see if we should exclude this dir */
  if (excludelist_lookup(instr)) {
	return 1;
  }

#ifdef DEBUG
  printf("Checking directory <%s>\n",instr);
#endif

  if (dirptr == NULL)
  {
    fprintf(stderr, "proc_dir_list: Can't open dir %s; errno=%d\n", instr, errno);
    return (1);
  }
  errno = 0;
  curr_path = (char *)malloc(MAXPATH + 1);
  if (curr_path == NULL)
  {
    fprintf(stderr, "proc_dir_list: Can't allocate enough space; errno=%d\n", errno);
    closedir(dirptr);
    return (1);
  }
  memset(curr_path, '\0', MAXPATH+1);
  strncpy(curr_path, instr, MAXPATH);
  errno = 0;
  while ((direntptr = readdir(dirptr)) != NULL)
  {
    /* readdir give us everything and not necessarily in order. This 
       logic is just silly, but it works */
    if (((direntptr->d_name[0] == '.') &&
         (direntptr->d_name[1] == '\0')) ||
        ((direntptr->d_name[0] == '.') &&
         (direntptr->d_name[1] == '.') &&
         (direntptr->d_name[2] == '\0')))
      continue;

    errno = 0;
    strncat(curr_path, direntptr->d_name, MAXPATH);
    err = get_file_stat(curr_path, &fstat);

    if (err == -1)
    {
      if (errno == ENOENT)
        fprintf(stderr, "proc_dir_list: file %s not found, can't stat\n", curr_path);
      else
        fprintf(stderr, "proc_dir_list: Cannot stat file %s; errno=%d\n", curr_path, errno);
      closedir(dirptr);
      return (1);
    }
	if (check_mountpoint && (cur_dev_set == 0)) {
		cur_dev = fstat.st_dev;
#ifdef DEBUG
		fprintf(stderr,"Setting dev to %ld\n",(long)cur_dev);
#endif
		cur_dev_set = 1;
	}

#ifndef __MINGW32__
    /* Get rid of symlinks */
    if ((fstat.st_mode & S_IFMT) == S_IFLNK) {
#ifdef DEBUG
fprintf(stderr,"Skipping symlink %s\n",curr_path);
#endif
	curr_path[dir_name_len] = '\0';
	continue;
    }
#endif
    if ((fstat.st_mode & S_IFMT) == S_IFDIR)
    {
      strncat(curr_path, "/", MAXPATH);
      if (!check_mountpoint || (fstat.st_dev == cur_dev)) {
#ifdef DEBUG
		  fprintf(stderr,"Checking %s %ld %ld\n",curr_path,(long)fstat.st_dev,(long)cur_dev);
#endif
	      proc_dir_list(curr_path);
	  } else {
		fprintf(stderr, "Skipping mounted directory %s\n", curr_path);
	  }
    } else if ((fstat.st_size > 0) && ((fstat.st_mode & S_IFMT) == S_IFREG))
    {

      memset(&tmpbuf, '\0', 4096);
      if (escape_space(curr_path, tmpbuf) == 0)
      {
        /*
         * kludge, need to clean this up
         * later else any string matching in the path returns non NULL
         */
        if (logfilename != NULL)
          if (strstr(curr_path, logfilename) != NULL)
            fprintf(stderr, "We seem to be hitting our log file, so we'll leave this out of the search -> %s\n", curr_path);
          else
          {
#ifdef DEBUG
printf("Processing file %s\n",curr_path);
#endif
            ccsrch(curr_path, NOT_SPECIAL);
          }
        else
        {
#ifdef DEBUG
printf("Processing file %s\n",curr_path);
#endif
          ccsrch(curr_path, NOT_SPECIAL);
        }
      }
    }
#ifdef DEBUG
    else
    {
      if (fstat.st_size > 0)
        fprintf(stderr, "proc_dir_list: Unknown mode returned-> %x for file %s\n", fstat.st_mode,curr_path);
      else
        fprintf(stderr, "Not processing file of size 0 bytes: %s\n", curr_path);
    }
#endif
    curr_path[dir_name_len] = '\0';
  }

  free(curr_path);

  closedir(dirptr);
  return (0);
}

unsigned int getbin(int digs)
{
	unsigned int i = 0;
	unsigned int c = 0;
	
	while (--digs >= 0) {
		i *= 10;
		i += cardbuf[c++];
	}
	return i;
}


void 
check_mastercard_16(unsigned long offset)
{
  int             vnum = getbin(4);
	
  if ((vnum == 5002) || (vnum == 5007) || (vnum == 5016) || (vnum == 5020) || (vnum == 5030) || ((vnum >= 5035) && (vnum <= 5036)) || (vnum == 5043) || ((vnum >= 5045) && (vnum <= 5046)) || (vnum == 5048) || (vnum == 5078) || (vnum == 5081) || (vnum == 5084) || ((vnum >= 5100) && (vnum <= 5128)) || ((vnum >= 5130) && (vnum <= 5163)) || (vnum == 5166) || ((vnum >= 5169) && (vnum <= 5170)) || ((vnum >= 5176) && (vnum <= 5195)) || ((vnum >= 5200) && (vnum <= 5212)) || ((vnum >= 5214) && (vnum <= 5226)) || ((vnum >= 5228) && (vnum <= 5230)) || ((vnum >= 5232) && (vnum <= 5233)) || (vnum == 5236) || ((vnum >= 5238) && (vnum <= 5241)) || (vnum == 5243) || ((vnum >= 5247) && (vnum <= 5260)) || ((vnum >= 5262) && (vnum <= 5264)) || ((vnum >= 5266) && (vnum <= 5268)) || (vnum == 5270) || ((vnum >= 5273) && (vnum <= 5275)) || ((vnum >= 5277) && (vnum <= 5280)) || ((vnum >= 5282) && (vnum <= 5291)) || ((vnum >= 5293) && (vnum <= 5319)) || ((vnum >= 5321) && (vnum <= 5339)) || ((vnum >= 5341) && (vnum <= 5343)) || ((vnum >= 5347) && (vnum <= 5351)) || (vnum == 5353) || (vnum == 5359) || ((vnum >= 5362) && (vnum <= 5365)) || (vnum == 5369) || ((vnum >= 5376) && (vnum <= 5379)) || (vnum == 5383) || ((vnum >= 5387) && (vnum <= 5388)) || (vnum == 5390) || (vnum == 5393) || ((vnum >= 5396) && (vnum <= 5534)) || ((vnum >= 5536) && (vnum <= 5552)) || ((vnum >= 5559) && (vnum <= 5561)) || (vnum == 5563) || ((vnum >= 5566) && (vnum <= 5572)) || ((vnum >= 5577) && (vnum <= 5592)) || (vnum == 5612) || (vnum == 5768) || (vnum == 5817) || (vnum == 5854) || (vnum == 5888) || (vnum == 5890) || ((vnum >= 5892) && (vnum <= 5896)) || ((vnum >= 5898) && (vnum <= 5899)))
    print_result('M', 16, offset);
}

void
check_maestro_12_19(unsigned long offset, int cardLen)
{
  int  vnum = getbin(4);
  
  if ((vnum == 5018) || (vnum == 5020) || (vnum == 5038) || (vnum == 6304) || (vnum == 6759) || (vnum == 6761) || (vnum == 6763))
    print_result('m', cardLen, offset);
}

void 
check_solo_16_18_19(unsigned long offset, int cardLen)
{
  int  vnum = getbin(4);
  
  if ((vnum == 6334) || (vnum == 6767))
    print_result('s', cardLen, offset);
}

void 
check_switch_16_18_19(unsigned long offset, int cardLen)
{
  int  vnum1 = 0, vnum2 = 0;
  
  /* Get the 6-digit bin of the value */
  vnum1 = getbin(6);
  
  /* Get the 4-digit bin of the value */
  vnum2 = getbin(4);
  
  /* Test the 4 and 6-digit BIN ranges    */
  if ((vnum1 == 564182) || (vnum1 == 633110) || (vnum2 == 6333) || (vnum2 == 6759))
    print_result('S', cardLen, offset);
}

void 
check_visa_16(unsigned long offset)
{
  int             vnum = getbin(4);

  if (((vnum >= 4000) && (vnum <= 4004)) || ((vnum >= 4006) && (vnum <= 4013)) || ((vnum >= 4016) && (vnum <= 4043)) || ((vnum >= 4045) && (vnum <= 4050)) || ((vnum >= 4052) && (vnum <= 4064)) || ((vnum >= 4066) && (vnum <= 4082)) || ((vnum >= 4085) && (vnum <= 4122)) || ((vnum >= 4124) && (vnum <= 4161)) || ((vnum >= 4164) && (vnum <= 4170)) || ((vnum >= 4172) && (vnum <= 4180)) || ((vnum >= 4182) && (vnum <= 4203)) || ((vnum >= 4205) && (vnum <= 4207)) || ((vnum >= 4209) && (vnum <= 4211)) || ((vnum >= 4213) && (vnum <= 4229)) || ((vnum >= 4231) && (vnum <= 4233)) || ((vnum >= 4235) && (vnum <= 4239)) || ((vnum >= 4241) && (vnum <= 4247)) || ((vnum >= 4249) && (vnum <= 4283)) || ((vnum >= 4287) && (vnum <= 4344)) || (vnum == 4346) || ((vnum >= 4348) && (vnum <= 4349)) || ((vnum >= 4351) && (vnum <= 4353)) || ((vnum >= 4355) && (vnum <= 4357)) || (vnum == 4361) || ((vnum >= 4366) && (vnum <= 4368)) || (vnum == 4373) || ((vnum >= 4378) && (vnum <= 4382)) || ((vnum >= 4384) && (vnum <= 4395)) || ((vnum >= 4397) && (vnum <= 4436)) || ((vnum >= 4438) && (vnum <= 4468)) || ((vnum >= 4470) && (vnum <= 4525)) || ((vnum >= 4529) && (vnum <= 4571)) || ((vnum >= 4579) && (vnum <= 4581)) || (vnum == 4588) || ((vnum >= 4598) && (vnum <= 4608)) || ((vnum >= 4610) && (vnum <= 4613)) || ((vnum >= 4616) && (vnum <= 4617)) || ((vnum >= 4619) && (vnum <= 4632)) || ((vnum >= 4634) && (vnum <= 4668)) || ((vnum >= 4670) && (vnum <= 4676)) || ((vnum >= 4678) && (vnum <= 4682)) || ((vnum >= 4684) && (vnum <= 4685)) || ((vnum >= 4687) && (vnum <= 4696)) || ((vnum >= 4700) && (vnum <= 4708)) || (vnum == 4712) || ((vnum >= 4715) && (vnum <= 4739)) || ((vnum >= 4741) && (vnum <= 4748)) || ((vnum >= 4750) && (vnum <= 4751)) || ((vnum >= 4754) && (vnum <= 4758)) || ((vnum >= 4760) && (vnum <= 4770)) || ((vnum >= 4773) && (vnum <= 4775)) || ((vnum >= 4777) && (vnum <= 4780)) || ((vnum >= 4782) && (vnum <= 4784)) || ((vnum >= 4786) && (vnum <= 4795)) || ((vnum >= 4797) && (vnum <= 4804)) || ((vnum >= 4806) && (vnum <= 4809)) || ((vnum >= 4811) && (vnum <= 4822)) || (vnum == 4825) || ((vnum >= 4827) && (vnum <= 4831)) || ((vnum >= 4833) && (vnum <= 4835)) || ((vnum >= 4837) && (vnum <= 4847)) || ((vnum >= 4850) && (vnum <= 4870)) || ((vnum >= 4872) && (vnum <= 4875)) || (vnum == 4888) || ((vnum >= 4892) && (vnum <= 4893)) || ((vnum >= 4895) && (vnum <= 4897)) || ((vnum >= 4899) && (vnum <= 4902)) || (vnum == 4904) || ((vnum >= 4906) && (vnum <= 4910)) || ((vnum >= 4912) && (vnum <= 4925)) || ((vnum >= 4929) && (vnum <= 4931)) || ((vnum >= 4934) && (vnum <= 4935)) || ((vnum >= 4937) && (vnum <= 4938)) || ((vnum >= 4940) && (vnum <= 4941)) || (vnum == 4943) || (vnum == 4946) || (vnum == 4950) || (vnum == 4960) || (vnum == 4966) || ((vnum >= 4970) && (vnum <= 4980)) || ((vnum >= 4984) && (vnum <= 4986)) || (vnum == 4988) || (vnum == 4999))
    print_result('V', 16, offset);
}

void 
check_discover_16(unsigned long offset)
{
  int vnum6 = 0, vnum3 = 0, vnum2 = 0, vnum4 = 0;

  vnum2 = getbin(2); 
  vnum3 = getbin(3);
  vnum4 = getbin(4);
  vnum6 = getbin(6);
    
  if (((vnum6 >= 622126) && (vnum6 <= 622925)) || ((vnum3 >= 644) && (vnum3 <= 649)) || (vnum2 == 65) || (vnum4 == 6011))
    print_result('D', 16, offset);
}

void 
check_jcb_16(unsigned long offset)
{
  int             vnum = getbin(4);

  if ((vnum == 3088) || (vnum == 3096) || (vnum == 3112) || (vnum == 3158) || (vnum == 3337) || (vnum == 3528) || (vnum == 3529))
    print_result('J', 16, offset);
}

void 
check_amex_15(unsigned long offset)
{
  int             vnum = getbin(4);

if (((vnum >= 3702) && (vnum <= 3703)) || (vnum == 3710) || ((vnum >= 3712) && (vnum <= 3713)) || (vnum == 3715) || (vnum == 3718) || (vnum == 3723) || (vnum == 3725) || ((vnum >= 3727) && (vnum <= 3728)) || ((vnum >= 3731) && (vnum <= 3733)) || ((vnum >= 3737) && (vnum <= 3738)) || (vnum == 3743) || (vnum == 3746) || (vnum == 3753) || (vnum == 3756) || ((vnum >= 3762) && (vnum <= 3764)) || (vnum == 3767) || (vnum == 3769) || ((vnum >= 3773) && (vnum <= 3774)) || (vnum == 3778) || ((vnum >= 3782) && (vnum <= 3783)) || (vnum == 3785) || (vnum == 3787) || (vnum == 3791) || (vnum == 3793))
    print_result('A', 15, offset);
} 

void 
check_enroute_15(unsigned long offset)
{
  int             vnum = getbin(4);

  if ((vnum == 2014) || (vnum == 2149))
    print_result('E', 15, offset);
}

void 
check_jcb_15(unsigned long offset)
{
  int             vnum = getbin(4);

  if ((vnum == 2131) || (vnum == 1800) || (vnum == 3528) || (vnum == 3529))
    print_result('J', 15, offset);
}

void 
check_diners_club_cb_14(unsigned long offset)
{
  int             vnum2 = 0;
  int             vnum3 = 0;

  vnum2 = getbin(2);
  vnum3 = getbin(3);

  if (((vnum3 > 299) && (vnum3 < 306)) || ((vnum3 > 379) && (vnum3 < 389)) || (vnum2 == 36))
    print_result('d', 14, offset);
}

void 
cleanup_shtuff()
{
  time_t end_time=0;

  end_time=time(NULL);
  if (postprocess) {
	fprintf(outfile(),"E|FC|%ld\n",file_count);
	fprintf(outfile(),"E|T|%ld\n",(long)(time(NULL) - init_time));
#ifdef WINDOWS
	fprintf(outfile(),"E|B|%llu\n",byte_count);
#else
	fprintf(outfile(),"E|B|%lu\n",byte_count);
#endif
	fprintf(outfile(),"E|I|%ld\n",(long)inaccessible_cnt);
	fprintf(outfile(),"E|L|%s\n",location);
	fprintf(outfile(),"E|W|%d\n",whitelist_cnt);
  } else {
	  fprintf(stdout, "\n\nFiles or Devices searched ->\t%ld\n", file_count);
#ifdef WINDOWS
	  if (windrive) {
		  fprintf(stdout, "\n\nBlocks searched ->\t\t%u\n", block_count);
	  }
#endif
	  fprintf(stdout, "Search time (seconds) ->\t%ld\n", (long)(time(NULL) - init_time));
	  fprintf(stdout, "Credit card matches ->\t\t%ld\n", total_count);
	  if (whitelist_cnt > 0)
	    fprintf(stdout, "Whitelist eliminated ->\t%d\n",whitelist_cnt);
	  if (tracksrch)
	    fprintf(stdout, "Track data pattern matches ->\t%d\n\n", trackdatacount);
	  fprintf(stdout, "\nLocal end time: %s\n\n", ctime((time_t *)&end_time));
	}

}

void 
process_cleanup(sig)
int sig;
{
  if (logfilefd != NULL)
    fclose(logfilefd);
  cleanup_shtuff();
  exit(0);
}

void
dumplastfile(sig)
int sig;
{
	fprintf(stderr,"Last file read was %s\n\r",currfilename);
	fflush(stdout);
	process_cleanup(sig);
}

void 
signal_proc()
{
  signal(SIGHUP, process_cleanup);
  signal(SIGTERM, process_cleanup);
  signal(SIGINT, dumplastfile);
  signal(SIGQUIT, process_cleanup);
}

void 
usage(char *progname)
{
  printf("%s\n", PROG_VER);
  printf("Usage: %s <options> <start path or - for stdin>\n", progname);
  printf("  where <options> are:\n");
  printf("    -b\t\t   Print the byte offset of the PAN in the file\n"); 
  printf("    -e\t\t   Include the Modify Access and Create times in terms \n\t\t   of seconds since the epoch\n");
  printf("    -f\t\t   Only print the filename w/ potential PAN data\n"); 
  printf("    -F\t\t   Take file-list as input.  Ignores dirs and is not recursive.  Use with find.\n"); 
  printf("    -j\t\t   Include the Modify Access and Create times in terms \n\t\t   of normal date/time\n");
  printf("    -o <filename>  Output the data to the file <filename> vs. standard out\n");
  printf("    -O\t\t   Output the data to a file called cc-HOSTNAME-MMDDYYHHMM.out\n");
  printf("    -t <1 or 2>\t   Check if the pattern follows either a Track 1 \n\t\t   or 2 format\n");
  printf("    -T\t\t   Check for both Track 1 and Track 2 patterns\n");
  /* Begin EPX Modifications */
  printf("    -u\t\t   Unsafe mode: Output will not be masked. Use with caution!\n");
  /*  End EPX Modifications */
  printf("    -U\t\t   Unfiltered - do not filter based on basic rules.  Use for finding test cards (e.g. 4111111111111111)\n");
  printf("    -m\t\t   Check mountpoints - do not traverse onto a new mounted device\n");
  printf("    -x <excludelist>\t\t   Comma separated exclude list of extensions (e.g \"DLL,EXE\")\n");
  printf("    -X <filename>\t\t   File containing directories to exclude\n");
  printf("    -w <filename>\t\t   Use PANs in filename as a whitelist to drop\n");
  printf("    -W <filename>\t\t   Use PANs in filename as a whitelist to only report on\n");
  printf("    -l limit\t\t   Maximum positive PANs found in a file before skipping\n");
  printf("    -L limit\t\t   Maximum # of bytes read in a file before skipping (may end in G for Gigabytes or M for Megabytes)\n");
  printf("    -s X\t\t   Output X bytes surrounding the PAN. X:Y specifies X pre and Y post bytes. Possibly unsafe, see manual.\n");
  printf("    -R <filename>\t\t   Restore aborted search: ignore files until the specified filename is found\n");
  printf("    -p\t\t   Output suitable for postprocessing\n");
#if defined(LINUX) || defined (WINDOWS)
  printf("    -P pid\t\t   Search memory of specified process.\n");
#endif
#ifdef WINDOWS
  printf("    -D\t\t   The filename will be a windows logical or physical drive letter or number.  Use only for forensics\n");
#endif
  printf("    -h\t\t   Help (this information)\n\n");
  printf("Please see the README file for a description of how this program works.\n\n");
  exit(0);
}

int 
open_logfile()
{
  errno = 0;
  if (logfilename!=NULL)
  {
    logfilefd = fopen(logfilename, "w");
    if (logfilefd == NULL)
    {
      fprintf(stderr, "Unable to open logfile %s for writing; errno=%d\n", logfilename, errno);
      return (-1);
    }
  }
  return (0);
}


int check_dir (char *name)
{
  DIR            *dirptr;
  
  dirptr = opendir(name);
  if (dirptr!=NULL)
  {
    closedir(dirptr);
    return(1);
  }
  else
    return (0);
}



int 
main(int argc, char *argv[])
{
  struct stat	ffstat;
  char		*inputstr = NULL;
  char		*inbuf = NULL;
  char		*tracktype_str=NULL;
  char		tmpbuf[4096];
  char	filename[MAXPATH];
  FILE	*file_list;
  int		inlen = 0, err=0, c=0, createlogfilename = 0;
  char	*limitarg;
  char	limitend;
  int		domegs = 0, dogigs = 0;
  char	locallogfilename[1024];
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  char *separator;	
#ifdef WINDOWS
  int physdr = -1;
  char logdr = '\0';
  DWORD dwVersion = 0; 
  DWORD dwMajorVersion = 0;
  DWORD dwMinorVersion = 0; 
  DWORD dwBuild = 0;
  OSVERSIONINFOEX osvi;
  char winver[256];
  char uname[UNLEN+1];
  DWORD username_len = UNLEN+1;
  TCHAR infoBuf[150];
  DWORD bufCharCount = 150;
#endif
  register struct passwd *pw;
  char host[256];
  char username[24];
  char *hosttype;

  if (argc < 2)
    usage(argv[0]);

#ifdef WINDOWS
	GetUserName(uname, &username_len);
	strncpy(username,uname,24);
#else
  pw = getpwuid(geteuid());
  if (pw) {
      strncpy(username,pw->pw_name,24);
  }
#endif

#ifdef WINDOWS
  while ((c = getopt(argc, argv,"befhFjt:TmOo:s:uPpw:W:Dx:X:l:L:UR:")) != -1)
#else
#ifdef LINUX
  while ((c = getopt(argc, argv,"befhFjt:TmOo:s:uPpw:W:x:X:l:L:UR:")) != -1)
#else
  while ((c = getopt(argc, argv,"befhFjt:TmOo:s:upw:W:x:X:l:L:UR:")) != -1)
#endif
#endif
  {
    switch (c)
    {
    case 'b':
      print_byte_offset=1;
      break;
    case 'e':
      print_epoch_time=1;
      break;
    case 'f':
      print_filename_only=1;
      break;
    case 'F':
      file_input=1;
      break;
    case 'j':
      print_julian_time=1;
      break;
    case 'o':
      logfilename=optarg;
      break;
    case 'O':
      createlogfilename = 1;
      break;
    case 't':
      tracksrch=1;
      tracktype_str=optarg;
      if (atoi(tracktype_str)==1)
        tracktype1=1;
      else if (atoi(tracktype_str)==2)
        tracktype2=1;
      else
        usage(argv[0]);
      break;
    case 'T':
      tracksrch=1;
      tracktype1=1;
      tracktype2=1;
      break;
	case 'p':
		postprocess = 1;
		break;
    case 'u':
	  safe_mode=0;
	  break;
	case 'm':
		check_mountpoint = 1;
		break;
	case 'U':
		no_filter = 1;
		break;
	case 'x':
			buildExcludeList(optarg);
			break;
	case 'X':
			loadExcludeFile(optarg);
			break;
    case 'w':
      wlfilename=optarg;
      break;
    case 'W':
      buildPanList(optarg);
	  panwl = 1;
      break;
#if defined(LINUX) || defined(WINDOWS)
	case 'P':
		pid_input = 1;
		break;
#endif
#ifdef WINDOWS
	case 'D':
			windrive = 1;
			print_byte_offset=1; /* auto turn on this too */
		break;
#endif
	case 'l':
		limitarg = optarg;
		if (limitarg != NULL) {
			if (atoi(limitarg)>0) {
				max_hits = atoi(limitarg);
			} else {
				usage(argv[0]);
			}
		}
		break;
	case 'L':
		limitarg = optarg;
		if (limitarg != NULL) {
			if (!isdigit(limitarg[strlen(limitarg)-1])) {
				limitend = limitarg[strlen(limitarg)-1];
				if ((limitend == 'M') || (limitend == 'm')) {
					domegs++;
				} else {
					if ((limitend == 'G') || (limitend == 'g')) {
						dogigs++;
					} else {
						usage(argv[0]);
					}
				}
			}
			if (atol(limitarg)>0) {
				max_bytes = atol(limitarg);
			} else {
				usage(argv[0]);
			}
			if (domegs)
				max_bytes *= 1024*1024; /* 1 Meg */
			if (dogigs)
				max_bytes *= 1024*1024*1024; /* 1 Gig */
		}
		break;
	case 's':
		if ((separator=strchr(optarg,':')) != NULL) {
			/* get both pre and post */
			*separator = '\0';
			surrounding_pre = atoi(optarg);
			surrounding_post = atoi(separator+1);
		} else {
			surrounding_pre = surrounding_post = atoi(optarg);
		}
		surrounding_pre = (surrounding_pre > MAXSURROUND) ? MAXSURROUND : surrounding_pre;
		surrounding_post = (surrounding_post > MAXSURROUND) ? MAXSURROUND : surrounding_post;
		break;
	case 'R':
		if (optarg != NULL) {
			resumefile = malloc(strlen(optarg)+1);
			strcpy(resumefile,optarg);
		} else usage(argv[0]);
		break;
    case 'h':
    default:
      usage(argv[0]);
      break;
    }
  } 

#ifdef WINDOWS

       memset(host, 0, 150);
       if( GetComputerName( infoBuf, &bufCharCount ) )
       {
           for(c=0; c<150; c++)
           {
               host[c] = infoBuf[c];
           }
       }
#else
	gethostname(host,256);
#endif

  inputstr = location = argv[optind];
  if (inputstr == NULL) {
	fprintf(stderr,"Must supply file or directory argument or \"-\" for input\n");
	usage(argv[0]);
  }
  inlen = strlen(inputstr) + 1;

  if (createlogfilename) {
	sprintf(locallogfilename,"cc-%s-%02d%02d%02d%02d%02d.out",host,tm.tm_year%100,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min);
	logfilename = locallogfilename;
  }

  if (open_logfile() < 0)
    exit(-1);
  if (open_whitelist() < 0) {
	exit(-1);
  }

	hosttype = "Unknown";
#if defined(WINDOWS)
		hosttype = "Windows";

		ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
		osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

		GetVersionEx((OSVERSIONINFO *)&osvi);

		// Get the Windows version.

		dwMajorVersion = (DWORD)osvi.dwMajorVersion;
		dwMinorVersion = (DWORD)osvi.dwMinorVersion;

		// Get the build number.

		if (dwVersion < 0x80000000)              
			dwBuild = (DWORD)(HIWORD(dwVersion));

		sprintf(winver,"Windows %d.%d %d", 
		                dwMajorVersion,
		                dwMinorVersion,
		                osvi.wProductType);
		hosttype = winver;
#else
	hosttype = "Unix";
#endif
	/* Now lets try to get more specific */
#if defined(__APPLE__)
	hosttype = "Mac OS X";
#endif
#if defined(_AIX)
	hosttype = "AIX";
#endif
#if defined(__linux__)
	hosttype = "Linux";
#endif
#if defined(__sun)
	hosttype = "Solaris";
#endif
#if defined(__hpux)
	hosttype = "HP-UX";
#endif
#if defined(BSD)
	hosttype = "BSD";
#endif
#if defined(__FreeBSD__)
	hosttype = "FreeBSD"; /* More specific */
#endif

  inbuf = (char *)malloc(inlen + 1);

  memset(inbuf, '\0', inlen+1);
  strncpy(inbuf, inputstr, inlen);

  signal_proc();

  init_time = time(NULL);

  if (postprocess) {
	fprintf(outfile(),"CCSRCH|%s\n",PROG_VER_SHORT);
	fprintf(outfile(),"S|U|%s\n",username);
	fprintf(outfile(),"S|H|%s\n",host);
	fprintf(outfile(),"S|t|%s\n",hosttype);	
	fprintf(outfile(),"S|S|%s",ctime((time_t *)&init_time));
	fprintf(outfile(),"S|V|%s\n",PROG_VER);
	fputs("S|A|",outfile());
	for (c=0;c<argc;c++) {
		fputs(argv[c],outfile());
		fputc((int)' ',outfile());
	}
	fputc((int)'\n',outfile());
  } else {
  	printf("\n%s\n", PROG_VER);
  	printf("\nLocal start time: %sHost: %s (%s)\n\n",ctime((time_t *)&init_time),host,hosttype);
  }

  if ((!file_input && (strcmp(inbuf,"-") == 0)) || (windrive == 1)) {
	if (resumefile != NULL) {
		fprintf(stderr,"Cannot use restore file (-R) with standard input\n");
		exit(1);
	}
	ccsrch(inbuf, IS_SPECIAL); /* special case */
  } else
  if (file_input) {
#ifdef DEBUG
	fprintf(stderr,"File input mode\n");
#endif
	/* Inputs are all filenames from file or standard input */
	if (strcmp(inbuf,"-") == 0) {
		file_list = stdin;
	} else {
		if ((file_list = fopen(inbuf,"r")) == NULL) {
			fprintf(stderr,"Unable to open file list %s\n",inbuf);
			exit(-1);
		}
	}
	while (fgets(filename,MAXPATH,file_list)!=NULL) {
		filename[strlen(filename)-1] = '\0'; /* trim off CR */
		err = get_file_stat(filename,&ffstat);
		if ((ffstat.st_size > 0) && ((ffstat.st_mode & S_IFMT) == S_IFREG)) {
			if (logfilename != NULL) {
				if (strstr(filename,logfilename) != NULL) {
					fprintf(stderr, "main: We seem to be hitting our log file, so we'll leave this out of the search -> %s\n", filename);
				} else {
					ccsrch(filename, NOT_SPECIAL);
				}
			}
		} 

	}

} else 
  if (pid_input) {
	ccsrch(inbuf,IS_PID);
} else
  if (check_dir(inbuf)) 
  {
#ifdef WINDOWS
    if ((inbuf[strlen(inbuf) - 1]) != '\\')
      inbuf[strlen(inbuf)] = '\\';
#else
    if ((inbuf[strlen(inbuf) - 1]) != '/')
      inbuf[strlen(inbuf)] = '/';
#endif
    proc_dir_list(inbuf);
  }
  else
  {
    err = get_file_stat(inbuf, &ffstat);
    if (err == -1)
    {
      if (errno == ENOENT)
        fprintf(stderr, "File %s not found, can't stat\n", inbuf);
      else
        fprintf(stderr, "Cannot stat file %s; errno=%d\n", inbuf, errno);
      exit (-1);
    }
	  if ((ffstat.st_mode & S_IFMT) != S_IFREG)
		  /* Special file... e.g. raw disk */
	  {		
		if (resumefile != NULL) {
			fprintf(stderr,"Cannot use restore file (-R) with device or disk\n");
			exit(1);
		}  
#ifdef DEBUG
					  printf("Processing special file %s\n",inbuf);
#endif
					  ccsrch(inbuf, NOT_SPECIAL); /* Note the special here refers to the file name not file type */

	  } else
    if ((ffstat.st_size > 0) && ((ffstat.st_mode & S_IFMT) == S_IFREG))
    {
      memset(&tmpbuf, '\0', 4096);
      if (escape_space(inbuf, tmpbuf) == 0)
      {
        if (logfilename != NULL)
          if (strstr(inbuf, logfilename) != NULL)
          fprintf(stderr, "We seem to be hitting our log file, so we'll leave this out of the search -> %s\n", inbuf);
          else
          {
#ifdef DEBUG
            printf("Processing file %s\n",inbuf);
#endif
            ccsrch(inbuf, NOT_SPECIAL);
          }
        else
        {
#ifdef DEBUG
          printf("Processing file %s\n",inbuf);
#endif
          ccsrch(inbuf, NOT_SPECIAL);
        }
      }
    }
    else if ((ffstat.st_mode & S_IFMT) == S_IFDIR)
    {
#ifdef WINDOWS
      if ((inbuf[strlen(inbuf) - 1]) != '\\')
        inbuf[strlen(inbuf)] = '\\';
#else
      if ((inbuf[strlen(inbuf) - 1]) != '/')
        inbuf[strlen(inbuf)] = '/';
#endif
	  proc_dir_list(inbuf);

    }
    else
      fprintf(stderr, "main: Unknown mode returned-> %x\n", ffstat.st_mode);
  }

  cleanup_shtuff();
  free(inbuf);

  return (0);
}

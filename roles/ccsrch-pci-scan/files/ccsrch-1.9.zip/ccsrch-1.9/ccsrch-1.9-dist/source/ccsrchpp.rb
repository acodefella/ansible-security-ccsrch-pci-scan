#!/usr/bin/env ruby
#
# ccsrch postprocessor (ccsrchpp.rb)
# Version 0.1: Basic postprocessing - Alpha
# Version 0.2: Added hotlist for TA
# Version 0.3: Added new CSS
# Version 0.4: Added expanded use of BIN tables
# Version 1.0: Added rollup report, made 1.0
#
# (c) Copyright 2016, PSC   All Rights Reserved
# The use of this tool by customer is licensed and governed by the terms and conditions of
# Client's agreement with PSC.

$version = "Version 1.0"

require 'optparse'
require 'tempfile'
# include sqlite3 here if compiling up with Ocra otherwise the other one won't be found.
require 'sqlite3' if Object.const_defined?(:Ocra)

def die(s)
  $stderr.puts s
  exit 1
end
 
$options = {}

optparse = OptionParser.new do |opts|
  opts.banner = "Usage: ccsrchpp.rb [options] files_to_parse"
#  $options[:verbose] = false
  opts.on( '-v', '--version', 'Output version' ) do
    puts $version
    exit
  end
  opts.on( '-h', '--help', 'Display this screen' ) do
    puts $version
    puts opts
    exit
  end
  $options[:exceptions] = nil
  opts.on( '-e', '--exceptions FILE', 'Read exceptions from file' ) do |file|
    $options[:exceptions] = file
  end
  $options[:hotlist] = nil
  opts.on( '-H', '--hotlist FILE', 'Read hotlist from file' ) do |file|
    $options[:hotlist] = file
  end
  $options[:country] = nil
  $options[:country_threshold] = 0.0
  opts.on( '-C', '--country X=Y', 'Threshold of % of PANs that must come from a particular country code (2 chars) - e.g. US=80.  Must be used with a BIN database' ) do |list|
    $options[:country] = list.split("=")[0]
    $options[:country_threshold] = list.split("=")[1].to_f
  end
  $options[:extensions] = nil
  opts.on( '-x', '--extensions LIST', 'List of extensions to skip over (comma separated, case insensitive).  These extensiosn will be used as well as the defaults' ) do |list|
    $options[:extensions] = list
  end
  $options[:extensions2] = nil
  opts.on( '-X', '--extensions LIST', 'List of extensions to skip over (comma separated, case insensitive).  These extensiosn will be used instead of the defaults' ) do |list|
    $options[:extensions2] = list
  end
  $options[:cardtypes] = "VMDA"
  opts.on( '-c', '--cardtypes LIST', 'List of cardtypes to search for (V=Visa,M=MasterCard,D=Discover,A=Amex,m=Maestro,d=Diners,E=Enroute,J=JCB,S=Switch,s=Solo default=VMDA)' ) do |list|
    $options[:cardtypes] = list
  end
  $options[:indexfile] = nil
  opts.on( '-i', '--index name', 'File to write as index to parsed files (HTML)' ) do |list|
    $options[:indexfile] = list
  end
  $options[:byteoffset] = false
  opts.on( '-b', '--byteoffset', 'Print byte offset as well as filename' ) do
    $options[:byteoffset] = true
  end
  $options[:threshold] = 0
  opts.on( '-t', '--threshold X', 'Require X minimum PANs to trigger reporting' ) do |list|
    $options[:threshold] = list.to_i
  end
  $options[:bindb] = nil
  opts.on( '-B', '--bindb X', 'Use bin database from file' ) do |file|
    $options[:bindb] = file
  end
  $options[:debug] = false
  opts.on( '-d', '--debug', 'Debug Mode' ) do |file|
    $options[:debug] = true
  end
end

optparse.parse!

$phdebug = $options[:debug]

if ($options[:country] != nil) && ($options[:bindb].nil?) then
    die "Must specify BIN database with --country option"
end

# read in exceptions to skip
$regexs = []
if ($options[:exceptions])
  begin
    File.readlines($options[:exceptions]).each do |line|
      $regexs << Regexp.new(line.strip) unless (line[0,1] == "#")
    end
  rescue => err
    die "Regular Expression Exception - check your regexs: #{err}"
  end
end

# read in hotlist to prioritize
$hotlist = []
if ($options[:hotlist])
  begin
    File.readlines($options[:hotlist]).each do |line|
      $hotlist << line.strip unless (line[0,1] == "#")
    end
  rescue => err
    die "Problem reading hotlist file: #{err}"
  end
end

if $options[:extensions2].nil?
  $extensions = [ "PDF", "ZIP", "RTF", "JAR", "JPEG", "JPG", "GIF", "BMP" ]
else
  $extensions = []
end
$extensions << $options[:extensions].split(",").map {|x| x.upcase} if $options[:extensions]
$extensions << $options[:extensions2].split(",").map {|x| x.upcase} if $options[:extensions2]
$extensions.flatten!

$g_tracklist = []

class Binlist 
  
  def initialize
    @sdb = nil
    unless $options[:bindb].nil?
      require 'sqlite3'
      begin
        @sdb = SQLite3::Database.new($options[:bindb])
        @sdb.results_as_hash = true
      rescue => err
        puts "Unable to open BIN database (error #{err.message})"
      end
    end
  end
  
  def lookup(bin)
    return "","","","","","" unless @sdb
    res = @sdb.execute("select * from bintable where bin = #{bin}")
    return "","","","","","" unless res
    res.each do |row|
      return row['brand'], row['country_code'], row['bank'], row['card_type'], row['card_category'], row['country_name']
    end 
  end

end

$bin = Binlist.new

def tracktab()
  return "" if $g_tracklist.empty?
  tt = ""
  $g_tracklist.each { |z| tt += "#{z}<br>"}
  tt
end

# Descriptions of all of the card types and their characteristics
$cardopts = [ 
  { :type => "V", :longtype => "Visa", },
  { :type => "M", :longtype => "MasterCard", },
  { :type => "m", :longtype => "Maestro", },
  { :type => "A", :longtype => "Amex", },
  { :type => "J", :longtype => "JCB", },
  { :type => "D", :longtype => "Discover", },
  { :type => "S", :longtype => "Switch", },
  { :type => "s", :longtype => "Solo", },
  { :type => "E", :longtype => "Enroute", },
  { :type => "d", :longtype => "Diners Club", }
]

$validopts = []
$g_summary = {}
$g_tracklist = []

$options[:cardtypes].split('').each { |x| $validopts << $cardopts.select {|y| y[:type] == x}[0]}

def htmlprsummary()
  val = ""
  $g_summary.sort_by { |k,v| k }.each do |x|
    val << "#{$validopts.select{|r| r[:type]==x[0]}[0][:longtype]}: #{x[1]} (#{((Float(x[1])/Float($g_pansfound))*100.0).to_i}%)<br>"
  end
  val
end

def htmlsummary(a)
  val = ""
  $validopts.each do |x|
    c = (a[x[:type]]) ? a[x[:type]].to_s : "0"
    val << "<td class=r>#{ c }</td>\n"
  end
  val
end

# if the dir wasn't specified, use PWD
if ARGV.empty?
  puts "No input files specified"
  exit 1
end

puts "PSC ccsrch postprocessor - #{$version}\n"

$headers = {}

$htmlheader = <<ENDOFHTML
<head>
<style>
body {
	background-color: #FFFFFF; 
	font-family:Open Sans, Lucida Sans Unicode, Lucida Grande, 
	sans-serif;
	font-size: 10pt; 
	text-align: left; 
}

b {
	color: #395596;
	font-size:12px;
	font-stretch:semi-expanded;
}

p.red {
	color: #FF0000;
}

p.orange {
	color: #FFA500;
}

@font-face {
    font-family: logoFont;
    src: url(COLONNA.TTF);
}

div.logo {
  font-family: 'Colonna MT', logoFont;
	font-size:104px;
}

div.reportpart {
	margin-top: 10px; 
	margin-bottom: 30px;
}

div.reportparttitle {
	background: -webkit-linear-gradient(35deg, #395596, #00c0ee); /* For Safari 5.1 to 6.0 */
  	background: -o-linear-gradient( 35deg, #395596, #00c0ee); /* For Opera 11.1 to 12.0 */
  	background: -moz-linear-gradient(35deg, #395596, #00c0ee); /* For Firefox 3.6 to 15 */
  	background: linear-gradient(35deg, #395596, #00c0ee); /* Standard syntax */
	width:100%;	 
	border: 1px solid #395596; 
	border-radius: 25px; 
	padding-top: 10px; 
	padding-bottom: 10px; 
	margin-top: 10px; 
	margin-bottom: 20px; 
	text-align: center; 
	font-size: 18px;
	color: #FFF;
	box-shadow: 10px 10px 5px #CCC;
	-moz-box-shadow: 10px 10px 5px #CCC;
	-webkit-box-shadow: 10px 10px 5px #CCC;
	-o-box-shadow: 10px 10px 5px #CCC;
}

div.reportsectiontitle {
	background: -webkit-linear-gradient(35deg, #395596, #00c0ee); /* For Safari 5.1 to 6.0 */
  	background: -o-linear-gradient( 35deg, #395596, #00c0ee); /* For Opera 11.1 to 12.0 */
  	background: -moz-linear-gradient(35deg, #395596, #00c0ee); /* For Firefox 3.6 to 15 */
  	background: linear-gradient(35deg, #395596, #00c0ee); /* Standard syntax */
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #395596; 
	border-radius: 25px;
	font-size: 16px; 
	font-weight: bold; 
	margin-top: 15px;
	margin-bottom: 25px;
	color: #FFF;
	white-space:pre-wrap;
	box-shadow: 10px 10px 5px #CCC;
	-moz-box-shadow: 10px 10px 5px #CCC;
	-webkit-box-shadow: 10px 10px 5px #CCC;
	-o-box-shadow: 10px 10px 5px #CCC;
}

div.reportsectionbody {
	margin-left: 20px; 
	margin-right: 20px;
	color: #333;
}

div.reportsectiontitlecritical {
	background: -webkit-linear-gradient(35deg, #FFF, #CCC); /* For Safari 5.1 to 6.0 */
  	background: -o-linear-gradient( 35deg, #FFF, #CCC); /* For Opera 11.1 to 12.0 */
  	background: -moz-linear-gradient(35deg, #FFF, #CCC); /* For Firefox 3.6 to 15 */
  	background: linear-gradient(35deg, #FFF, #CCC); /* Standard syntax */ 
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 2px solid #F00;
	border-radius: 25px; 
	font-size:12px; 
	font-weight: 500;
	color:#F00
}

div.reportsectiontitlehigh {
	background: -webkit-linear-gradient(35deg, #F00, #C10000); /* For Safari 5.1 to 6.0 */
  	background: -o-linear-gradient( 35deg, #F00, #C10000); /* For Opera 11.1 to 12.0 */
  	background: -moz-linear-gradient(35deg, #F00, #C10000); /* For Firefox 3.6 to 15 */
  	background: linear-gradient(35deg, #F00, #C10000); /* Standard syntax */ 
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #395596; 
	border-radius: 25px;
	font-size:12px;
	font-weight: 100;
	color:#FFF;
}

div.reportsectiontitlemedium {
	background: -webkit-linear-gradient(35deg, #F60, #F90); /* For Safari 5.1 to 6.0 */
  	background: -o-linear-gradient( 35deg, #F60, #F90); /* For Opera 11.1 to 12.0 */
  	background: -moz-linear-gradient(35deg, #F60, #F90); /* For Firefox 3.6 to 15 */
  	background: linear-gradient(35deg, #F60, #F90); /* Standard syntax */ 
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #395596; 
	border-radius: 25px;
	font-size:12px;
	font-weight: 75;
	color:#FFF;
}

div.reportsectiontitlelow {
	background: -webkit-linear-gradient(35deg, #FF0, #FF6); /* For Safari 5.1 to 6.0 */
  background: -o-linear-gradient( 35deg, #FF0, #FF6); /* For Opera 11.1 to 12.0 */
  background: -moz-linear-gradient(35deg, #FF0, #FF6); /* For Firefox 3.6 to 15 */
  background: linear-gradient(35deg, #FF0, #FF6); /* Standard syntax */ 
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #395596;
	border-radius: 25px;
	font-size:12px;
	font-weight: 50;
	color:#000;
}

div.reportsectiontitleinfo {
	background: #000; 
	padding:7px;
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #395596; 
	border-radius: 25px;
	font-size:16px; 
	font-weight: bold;
	color:#FFF;
}

div.reportlinebodyhigh {
	margin-left: 20px; 
	margin-right: 20px; 
	font-color: #00c0ee; 
	font-family: Open Sans, Lucida Sans Unicode, Lucida Grande, sans-serif;    
	padding: 5px; 
	padding-left: 15px;
	padding-right: 15px;
	font-size: 14px;
}

div.reportlinebody {
	margin-left: 20px; 
	margin-right: 20px; 
	font-family: Open Sans, Lucida Sans Unicode, Lucida Grande, sans-serif;    
	padding: 5px; 
	font-size: 14px;
}

div.reportlinebodysm {
	margin-left: 20px; 
	margin-right: 20px; 
	font-family: Open Sans, Lucida Sans Unicode, Lucida Grande, sans-serif;    
	padding: 5px; 
	font-size: 10px;
}

a:link {
	color: #00c0ee; 
	text-decoration: none;
}

a:visited {
	color:#333; 
	text-decoration: none;
}

a:hover {
	color: #395596; 
	text-decoration: none;
}

table {
	background-color: #F3F3F3; 
	width: 100%; 
	font-size: 12px; 
	padding:7px; 
	padding-left: 15px;
	padding-right: 15px;
	border: 1px solid #6E9BCD;
	border-radius: 25;
}

tr:nth-child(even) {
	background-color:#f9f9f9; }

td {
	vertical-align: top; 
	text-align: center; 
	padding: 3px;
}

td.l {
	vertical-align: top; 
	text-align: left;
	padding: 3px;
}

td.r {
	vertical-align: top; 
	text-align: right; 
	padding: 3px;
}

td.leftRed {
	vertical-align: top; 
	text-align: left; 
	padding: 3px;
	color: #FF0000;
}

td.left {
	text-align: left; 
}

td.red {
	color: #FF0000;
}

pre {
	background-color: #F3F3F3; 
	font-family: Open Sans, Lucida Sans Unicode, Lucida Grande, sans-serif;   
	white-space:pre-wrap;
	text-justify:inter-word;
	padding: 7px;
	border-width: 1px;
	border-style:groove;
	border: 1px solid #395596; 
	border-radius: 25px;
	font-size: 12px;
}
</style>
</head>
<body>
<script>
	function toggleDiv(elementIdx) {
		label1 = document.getElementById('psc_f_' + elementIdx);
		dispDiv = document.getElementById("psc_d_" + elementIdx);
		if (dispDiv.style.display == 'none') {
			label1.innerHTML = "&#x25BC";
			dispDiv.style.display = 'block';
		} else {
			label1.innerHTML = "&#x25B6";
			dispDiv.style.display = 'none';
		}
	}
</script>
ENDOFHTML


def prfilesize(i)
  b = i.to_i
  case
  when b < 1024 * 1024
    "#{i} bytes"
  when b < 1024 * 1024 * 1024
    sprintf("%0.1fMB",Float(b) / (Float(1024 * 1024)))
  else
    sprintf("%0.1fGB",Float(b) / (Float(1024 * 1024 * 1024)))
  end
end

def htmlheader()
  # Set up info vars
  htmlr = ""
  if ($g_pansfound + $g_tracksfound) > 0
    whatwefound = "<font style=\"color:red\">" + ($g_pansfound > 0 ? "Suspected PAN Data Discovered" : "") + ($g_tracksfound > 0 ? "<br>Track Data Discovered" : "") + "</font>"
  else
    whatwefound = "No track or pan data discovered"
  end

  htmlh =<<ENDOFHTML
  	  <div class=reportparttitle><div class=logo>PSC</div>
  		<p/>Ccsrch Postprocessor #{$version}<p/>Host CHD Scanning Report<p>Time of Scan: #{$headers[:starttime]}</div>
  		<div class=reportsectiontitle>Results of this scan</div>
  		<div class=reportsectionbody><b>#{whatwefound}</b></div>
  		<div class=reportsectiontitle>General System Information</div><p>
  		<div class=reportsectionbody>
  		  <p>Hostname</p>
  		  <pre>#{$headers[:host]}</pre>
  		  <p>OS Version</p>
  		  <pre>#{$headers[:ostype]}</pre>
  		  <p>User Running Ccsrch</p>
  		  <pre>#{$headers[:user]}</pre>
  	  </div>
  		<div class=reportsectiontitle>Scan Information</div><p>
  		<div class=reportsectionbody>
  		  <p>Ccsrch Version</p>
		    <pre>#{$headers[:version]}</pre>
		    <p>Ccsrch Command Line</p>
		    <pre>#{$headers[:cmdline]}</pre>
  		  <p>Total Scan Time</p>
  		  <pre>#{$headers[:elapsed]} Seconds</pre>
        <p>Total Files Scanned</p>
        <pre>#{$headers[:filecount]} Files</pre>
        <p>Total Files Of Interest</p>
        <pre>#{$g_reported_files} Files</pre>
        <p>Total Bytes Scanned</p>
        <pre>#{prfilesize($headers[:bytecount])}</pre>
        <p>Threshold of PANs per File to Report</p>
        <pre>#{$options[:threshold] == 0 ? "No Threshold Set" : $options[:threshold]}</pre>
        <p>Inaccessible Locations</p>
        <pre>#{$headers[:ignored]} Files</pre>
        <p>Location Included In Scan</p>
  		  <pre>#{$headers[:location]}</pre>
        <p>PANs or Track Data Found</p>
        <pre>#{$g_pansfound + $g_tracksfound} (+#{$g_testcards} test numbers)</pre>
        <p>Card Schemes Scanned</p>
        <pre>#{htmlprsummary}</pre>
  	  </div>	
ENDOFHTML

  if $g_tracksfound > 0
    htmlr = <<ENDOFHTML2
    <div class=reportsectiontitlecritical>Track Data Found</div><p>
		<div class=reportsectionbody>
		  <p>Track Data found in the following files <i>(n.b. thresholds have been overridden for these files)</i>:</p>
      <pre>#{tracktab}</pre>
    </div>
ENDOFHTML2
  end
  $htmlheader + htmlh + htmlr
end

def htmlsectioninit(level)
    $htmltmp[level] = Tempfile.new("ccsrch"+level.to_s)
    
    case level
    when 0
      htmlclass = "reportsectiontitlelow"
      title = "Unlikely to contain PAN data"
    when 1
      htmlclass = "reportsectiontitlemedium"
      title = "Possible PAN data discovered"
    when 2
      htmlclass = "reportsectiontitlehigh"
      title = "Probable PAN data discovered"
    end
    
    headerrow = "<tr><th style=\"width:800px;text-align:left\">File Name</th>\n"
    $validopts.each { |z| headerrow += "<th style=\"width:40px\">#{z[:longtype]}</th>\n"}
    headerrow += "</tr>"
    html1 = <<ENDHTML
    <div class=#{htmlclass}>#{title}</div><p>
    <table>
    #{headerrow}
ENDHTML
    $htmltmp[level].write(html1)
end

def htmlsectionclose(outfile,x)
  $htmltmp[x].write("</table>\n")
  if $htmltmpfilecount[x] > 0
    # We have stuff to report
    $htmltmp[x].rewind
    outfile.write($htmltmp[x].read)
  end
  $htmltmp[x].close
  $htmltmp[x].unlink
end

def htmlfooter()
  begin
    htmlclose = <<HTMLCLOSE
  <div class=reportsectiontitle>
  Ccsrch Processor Tool Settings and Options
  </div>
  <div class=reportsectionbody>
    <p>Ccsrch Postprocessor #{$version} run #{$g_start}
    <br />Run by #{ENV['USER'] ? ENV['USER'] : ENV['USERNAME']}</p><p>&copy Copyright 2016, PSC   All Rights Reserved<br />
    The use of this tool by customer is licensed and governed by the terms and conditions of Client's agreement with <a href='http://www.paysw.com'>PSC</a>.</p>
  </div>    
<p>&nbsp;<p>
<p>&nbsp;<p>
</body>
</html>
HTMLCLOSE
    return htmlclose
  rescue => err
    STDERR.puts "Unable to write HTML output file #{$options[:html]}: #{err}"
  end
end

def procheader(fields)
  value = fields[2]
  header = case fields[1]
  when "U"
    :user
  when "H"
    :host
  when "S"
    :starttime
  when "V"
    :version
  when "FC"
    :filecount
  when "T"
    :elapsed
  when "B"
    :bytecount
  when "I"
    :ignored
  when "L"
    :location
  when "W"
    :whitelistcnt
  when "t"
    :ostype
  when 'A'
    :cmdline
  else
    :unknown
  end
  $headers[header] = value
  # special processing
  case header
  when :ostype
    if value =~ /Windows.*/
      $extensions << [ "EXE", "DLL", "MANIFEST", "TTF", "COM", "BIN", "MSI", "PSD" ]
      $extensions.flatten!
      parts = value.split(' ')
      majmin = parts[1]
      prodtype = parts[2].to_i
      $headers[header] = case majmin
           when '5.0'
             "Windows 2000"
           when '5.1'
             "Windows XP"
           when '5.2'
             "Windows Server 2003"
           when '6.0'
             prodtype == 1 ? "Windows Vista" : "Windows Server 2008"
           when '6.1'
             prodtype == 1 ? "Windows 7" : "Windows Server 2008 SP2"
           when '6.2'
             prodtype == 1 ? "Windows 8" : "Windows Server 2012"
           when '6.3'
             prodtype == 1 ? "Windows 8.1" : "Windows Server 2012 R2"
           when '10.0'
             "Windows 10"
           else
             "Unknown Version of Windows: Platform #{majmin} Product Type #{prodtype}"
           end
    end
  end
end

def procfile(fields)
  
  $skipfile = false
  $curfilename = fields[1]
  ext = File.extname($curfilename)
  if ext != "" && ! $extensions.empty?
    # we have both an extension and an non-empty extensions list
    ext.upcase!
    ext = ext[1,100]
    if $extensions.include? ext
      $skipfile = true
      return
    end
  end
  
  # Now see if it matches a regex
  unless $regexs.empty?
    $regexs.each do |x|
      if $curfilename =~ x then
       $skipfile = true
       return
      end
    end
  end
  

  $f_curList = ""
  $f_summary = {}
  $f_country = {}
  $f_level = 0
  $f_pancount = 0
  $f_tpancount = 0
  $f_tracksfound = 0
  $f_hotlist = 0
  
end

def prochit(fields)
  return if $skipfile
  
  pan = fields[1]
  type = fields[2]
  td = fields[3].to_i
  byteoffset = fields[4]
  context = fields[5]
  
  $f_tpancount += 1
  
  # See if it is one of our PAN types otherwise return
  return if $options[:cardtypes].index(type).nil?
  
  $f_pancount += 1
  $g_pansfound += 1
  
  # update per file summary
  if $f_summary[type].nil?
    $f_summary[type] = 1
  else
    $f_summary[type] += 1
  end
  
  # update global summary
  if $g_summary[type].nil?
    $g_summary[type] = 1
  else
    $g_summary[type] += 1
  end
  
  # up level significantly if we see track data
  $f_level += 2 if td > 0
  
  # up level if it's on the hotlist
  $hotlist.each { |x| $f_hotlist = 1 if pan.index(x) == 0 }
  
  if td > 0
    $g_tracksfound += 1
    $f_tracksfound += 1
  end
  
  cardtype = $cardopts.select { |x| x[:type] == type }[0]
  
  brand, country_code, bank, card_type, card_category, country = $bin.lookup(pan[0..5])
  
  # update country code list for map
  if $f_country[country_code].nil?
    $f_country[country_code] = 1
  else
    $f_country[country_code] += 1
  end
  
  disp =  "#{brand == '' ? cardtype[:longtype] : ''} " + (td > 0 ? "Track #{td} data: " : "") + "#{pan} "
  disp = disp + "&nbsp;[#{context}]" if context and context != ""
  disp = disp + "&nbsp;Brand = #{brand == '' ? 'Unknown' : brand} , Bank = #{bank == '' ? 'Unknown' : bank} , Country = #{country == ''? 'Unknown' : country} , Type = #{card_type == '' ? 'Unknown' : card_type}, Category = #{card_category == '' ? 'Unknown' : card_category }" if $options[:bindb]
  
  $f_curList << "#{disp}<br>\n" 
end

def finishfile(fields)
  return if $skipfile
  
  return if $f_pancount == 0
  
  if $f_tracksfound > 0
    $g_tracklist << fields[1]
  else  # threshold based file skips
    if ($options[:threshold] > 0) && ($f_pancount < $options[:threshold])
      return
    end
    # Calculate % of all PANs for a country and skip those that don't meet the threshold
    cpercent = 0.0
    unless ($options[:country].nil?) then
      cpercent = Float($f_country[$options[:country]])/$f_pancount*100 unless $f_country[$options[:country]].nil?
      return unless (cpercent > 0) and (cpercent > $options[:country_threshold])
    end
  end
  
  $g_reported_files += 1
  
  # File Level heuristics
    
  # if the number of PANs of our types vs. all types is > 80% increment probability of file being real
  $f_level += 1 if (Float($f_pancount)/Float($f_tpancount)*100).to_i >= 80
  
  # if the number of PANs that pass all checks vs. pass LUHN checks is > 70% increment probability of file being real
  $f_level += 1 if (Float($f_pancount)/Float(fields[2])*100).to_i >= 80
  
  # if the number of filtered PANs is < 10% increment probability of being real
  $f_level += 1 if (Float(fields[3])/$f_pancount*100).to_i <= 10
  
  # Increase if we've seen any hostlisted BINs
  $f_level += 1 if $f_hotlist == 1
  
  $f_level = 2 if $f_level > 2
  
  # if small PANs, reduce the number
  $f_level -= 1 if $f_pancount < 5
  $f_level = 0 if $f_level < 0
  
  $htmltmpfilecount[$f_level] += 1
  $htmltmp[$f_level].write("<tr><td class=l><label id='psc_f_#{$g_reported_files}' onclick='toggleDiv(#{$g_reported_files})'>&#x25B6</label> #{fields[1]}\n<div class='reportlinebodysm' id='psc_d_#{$g_reported_files}' style='display:none'>\n<p>#{$f_curList}<p></div></td>\n#{htmlsummary($f_summary)}</tr>\n")
end

def parsefile(f)
  begin
    infile = File.open(f,"r")
    firstline = infile.gets
    unless firstline =~ /CCSRCH/
      puts "File #{f} is not a valid ccsrch postprocessor file\n"
      return
    end
    
    $g_pansfound = $g_tracksfound = $g_testcards = $g_reported_files = 0
    $g_summary = {}
    $g_start = Time.now    
    $htmltmpfilecount = []
    $htmltmp = []
    
    0.upto(2) { |x| $htmltmpfilecount[x] = 0; htmlsectioninit(x) }
    
    newf = File.join(File.dirname(f),File.basename(f,File.extname(f)) + ".html")    
    outfile = File.open(newf,"w")
    
    puts "Processing file #{f} into #{newf}"
    
    while inline = infile.gets
      inline.strip!
      infields = inline.split("|")
      case infields[0]
      when "S"
        procheader(infields)
      when "F"
        procfile(infields)
      when "H"
        prochit(infields)
      when "FE"
        finishfile(infields)
      when "E"
        procheader(infields)
      else
        puts "Corrupted file format at line #{inline}"
        return
      end
    end
    
    # Now construct output file
    outfile.write(htmlheader())
    2.downto(0) { |x| htmlsectionclose(outfile,x) }
    outfile.write(htmlfooter())
    
    if ($options[:indexfile])
      newf = "file://"+File.expand_path(newf) if newf[0] == "/"  # Make into File URL if complete path otherwise relative
      row = "<tr><td style=\"text-align:left\"><a href='#{newf}'>#{$headers[:host]}</a></td>\n"
      row += "<td>#{$headers[:ostype]}</td>\n"
      row += "<td>#{$headers[:starttime]}</td>\n"
      row += "<td>#{prfilesize($headers[:bytecount])}</td>\n"
      row += "<td>#{$headers[:filecount]}</td>\n"
      row += "<td>#{$g_reported_files}</td>\n"
      row += "<td>#{$htmltmpfilecount[2]}</td>\n"
      row += "<td>#{$htmltmpfilecount[1]}</td>\n"
      row += "<td>#{$htmltmpfilecount[0]}</td>\n"
      row += "<td>#{$f_tracksfound}</td>\n"
      row += "</tr>"
      $indexfp.write(row)
    end
    
  rescue => err
    puts err
  end
end

$indexfp = nil

def indexheader
  begin
    $indexfp = File.open($options[:indexfile],"w")
    $indexfp.write($htmlheader)
    localHeader =<<ENDOFHTML
      	  <div class=reportparttitle><div class=logo>PSC</div>
      		<p/>Ccsrch Postprocessor #{$version}<p/>Cardholder Data Scanning Report<p>Time of Report: #{Time.now}</div>
      		<div class=reportsectiontitle>Results of the Scans</div><p>

ENDOFHTML
    $indexfp.write(localHeader)
    headerrow = "<tr><th style=\"width:420px;text-align:left\">System Name</th>\n"
    headerrow += "<th style=\"width:60px\">OS</th>\n"
    headerrow += "<th style=\"width:60px\">Scan Date/Time</th>\n"
    headerrow += "<th style=\"width:60px\">Bytes Scanned</th>\n"
    headerrow += "<th style=\"width:60px\">Files Scanned</th>\n"
    headerrow += "<th style=\"width:60px\">Total Files Flagged</th>\n"
    headerrow += "<th style=\"width:60px\">Files with Probable PANs</th>\n"
    headerrow += "<th style=\"width:60px\">Files with Possible PANs</th>\n"
    headerrow += "<th style=\"width:60px\">Files with Unlikely PANs</th>\n"
    headerrow += "<th style=\"width:60px\">Tracks</th>\n"
    headerrow += "</tr>"
    $indexfp.write("<table>\n"+headerrow)
  rescue => err
    puts err
  end
end

def indexfooter
  begin  
    $indexfp.write("</table>\n<p>")
    $indexfp.write(htmlfooter())
  rescue => err
    puts err
  end
end


indexheader if ($options[:indexfile])

ARGV.each do |parseme|
  STDERR.puts "Parsing #{parseme}" if $phdebug

  parsefile(parseme)
  
end

indexfooter if ($options[:indexfile])

